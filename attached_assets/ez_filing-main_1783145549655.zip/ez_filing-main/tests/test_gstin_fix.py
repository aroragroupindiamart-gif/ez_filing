"""Retest bug fix: vendor_gstin invalid/missing -> itc_eligible must be False."""
import io
import os
import sys
import requests
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4

BASE = "https://prd-zip-workshop.preview.emergentagent.com/api"


def make_pdf(lines):
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    y = 800
    for line in lines:
        c.drawString(50, y, line)
        y -= 20
    c.showPage()
    c.save()
    buf.seek(0)
    return buf.getvalue()


def upload(pdf_bytes, name):
    files = {"file": (name, pdf_bytes, "application/pdf")}
    r = requests.post(f"{BASE}/vendor-invoices", files=files, timeout=120)
    return r


def reset():
    r = requests.delete(f"{BASE}/reset", timeout=30)
    assert r.status_code == 200, r.text


def run():
    results = {"passed": [], "failed": []}

    invalid_pdf = make_pdf([
        "Tax Invoice",
        "Vendor Name: BadVendor Co.",
        "GSTIN: INVALID123",
        "Invoice No: INV-BAD-001",
        "Invoice Date: 2025-01-10",
        "HSN: 998877",
        "Description: Consulting services",
        "Taxable Value: 10000",
        "Rate: 18",
        "CGST: 900",
        "SGST: 900",
        "IGST: 0",
        "CESS: 0",
    ])

    missing_pdf = make_pdf([
        "Tax Invoice",
        "Vendor Name: NoGSTIN Traders",
        "Invoice No: INV-NOGST-002",
        "Invoice Date: 2025-01-11",
        "HSN: 998877",
        "Description: Software licenses",
        "Taxable Value: 5000",
        "Rate: 18",
        "CGST: 450",
        "SGST: 450",
        "IGST: 0",
        "CESS: 0",
    ])

    valid_pdf = make_pdf([
        "Tax Invoice",
        "Vendor Name: GoodVendor Pvt Ltd",
        "GSTIN: 27AABCA1234B1Z5",
        "Invoice No: INV-GOOD-100",
        "Invoice Date: 2025-01-12",
        "HSN: 998877",
        "Description: Cloud hosting services",
        "Taxable Value: 20000",
        "Rate: 18",
        "CGST: 1800",
        "SGST: 1800",
        "IGST: 0",
        "CESS: 0",
    ])

    # Test 1: Invalid GSTIN
    reset()
    r = upload(invalid_pdf, "invalid_gstin.pdf")
    print("T1 status:", r.status_code)
    print("T1 body:", r.text[:500])
    if r.status_code == 200:
        ex = r.json()["extracted"]
        cond = ex.get("vendor_gstin") is None and ex.get("itc_eligible") is False
        (results["passed"] if cond else results["failed"]).append(
            f"invalid_gstin: vendor_gstin={ex.get('vendor_gstin')} itc_eligible={ex.get('itc_eligible')}"
        )
        # GSTR-3B regression: itc_net should be 0
        g = requests.get(f"{BASE}/compliance/gstr3b", timeout=30).json()
        oth = next(x for x in g["itc_elg"]["itc_avl"] if x["ty"] == "OTH")
        net = g["itc_elg"]["itc_net"]
        cond2 = oth["iamt"] == 0 and oth["camt"] == 0 and oth["samt"] == 0 and \
                net["iamt"] == 0 and net["camt"] == 0 and net["samt"] == 0
        (results["passed"] if cond2 else results["failed"]).append(
            f"gstr3b_after_invalid: OTH={oth} net={net}"
        )
    else:
        results["failed"].append(f"invalid_gstin upload failed HTTP {r.status_code}: {r.text[:200]}")

    # Test 2: Missing GSTIN
    reset()
    r = upload(missing_pdf, "missing_gstin.pdf")
    print("T2 status:", r.status_code)
    print("T2 body:", r.text[:500])
    if r.status_code == 200:
        ex = r.json()["extracted"]
        cond = ex.get("vendor_gstin") is None and ex.get("itc_eligible") is False
        (results["passed"] if cond else results["failed"]).append(
            f"missing_gstin: vendor_gstin={ex.get('vendor_gstin')} itc_eligible={ex.get('itc_eligible')}"
        )
        g = requests.get(f"{BASE}/compliance/gstr3b", timeout=30).json()
        oth = next(x for x in g["itc_elg"]["itc_avl"] if x["ty"] == "OTH")
        net = g["itc_elg"]["itc_net"]
        cond2 = oth["iamt"] == 0 and oth["camt"] == 0 and oth["samt"] == 0 and \
                net["iamt"] == 0 and net["camt"] == 0 and net["samt"] == 0
        (results["passed"] if cond2 else results["failed"]).append(
            f"gstr3b_after_missing: OTH={oth} net={net}"
        )
    else:
        results["failed"].append(f"missing_gstin upload failed HTTP {r.status_code}: {r.text[:200]}")

    # Test 3: Valid GSTIN (happy path)
    reset()
    r = upload(valid_pdf, "valid_gstin.pdf")
    print("T3 status:", r.status_code)
    print("T3 body:", r.text[:500])
    if r.status_code == 200:
        ex = r.json()["extracted"]
        cond = ex.get("vendor_gstin") == "27AABCA1234B1Z5" and ex.get("itc_eligible") is True
        (results["passed"] if cond else results["failed"]).append(
            f"valid_gstin: vendor_gstin={ex.get('vendor_gstin')} itc_eligible={ex.get('itc_eligible')}"
        )
        g = requests.get(f"{BASE}/compliance/gstr3b", timeout=30).json()
        oth = next(x for x in g["itc_elg"]["itc_avl"] if x["ty"] == "OTH")
        # Should have non-zero ITC now
        cond2 = oth["camt"] > 0 and oth["samt"] > 0
        (results["passed"] if cond2 else results["failed"]).append(
            f"gstr3b_after_valid: OTH={oth}"
        )
    else:
        results["failed"].append(f"valid_gstin upload failed HTTP {r.status_code}: {r.text[:200]}")

    print("\n=== RESULTS ===")
    print("PASSED:")
    for p in results["passed"]:
        print("  +", p)
    print("FAILED:")
    for f in results["failed"]:
        print("  -", f)
    return 0 if not results["failed"] else 1


if __name__ == "__main__":
    sys.exit(run())
