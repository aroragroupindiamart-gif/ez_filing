from fastapi import FastAPI, APIRouter, UploadFile, File, HTTPException, Form, Depends, Cookie, Response, Request
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import io
import re
import json
import hashlib
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
from collections import defaultdict
import pandas as pd
import httpx
from pypdf import PdfReader
from emergentintegrations.llm.chat import LlmChat, UserMessage

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI()
api_router = APIRouter(prefix="/api")

# ------------------------------------------------------------------
# Reference data
# ------------------------------------------------------------------
STATE_CODES = {
    "01": "Jammu and Kashmir", "02": "Himachal Pradesh", "03": "Punjab", "04": "Chandigarh",
    "05": "Uttarakhand", "06": "Haryana", "07": "Delhi", "08": "Rajasthan",
    "09": "Uttar Pradesh", "10": "Bihar", "11": "Sikkim", "12": "Arunachal Pradesh",
    "13": "Nagaland", "14": "Manipur", "15": "Mizoram", "16": "Tripura",
    "17": "Meghalaya", "18": "Assam", "19": "West Bengal", "20": "Jharkhand",
    "21": "Odisha", "22": "Chhattisgarh", "23": "Madhya Pradesh", "24": "Gujarat",
    "25": "Daman and Diu", "26": "Dadra and Nagar Haveli", "27": "Maharashtra",
    "28": "Andhra Pradesh (Old)", "29": "Karnataka", "30": "Goa", "31": "Lakshadweep",
    "32": "Kerala", "33": "Tamil Nadu", "34": "Puducherry", "35": "Andaman and Nicobar",
    "36": "Telangana", "37": "Andhra Pradesh", "38": "Ladakh",
}
STATE_NAME_TO_CODE = {v.lower(): k for k, v in STATE_CODES.items()}
STATE_NAME_TO_CODE["andhra pradesh"] = "37"
STATE_NAME_TO_CODE["maharashtra"] = "27"
STATE_NAME_TO_CODE["delhi"] = "07"
STATE_NAME_TO_CODE["karnataka"] = "29"
STATE_NAME_TO_CODE["tamil nadu"] = "33"
STATE_NAME_TO_CODE["tamilnadu"] = "33"
STATE_NAME_TO_CODE["west bengal"] = "19"
STATE_NAME_TO_CODE["telangana"] = "36"
STATE_NAME_TO_CODE["uttar pradesh"] = "09"
STATE_NAME_TO_CODE["gujarat"] = "24"
STATE_NAME_TO_CODE["rajasthan"] = "08"
STATE_NAME_TO_CODE["kerala"] = "32"

SELLER_STATE_CODE_DEFAULT = "27"  # Maharashtra
GSTIN_RE = re.compile(r"^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$")

# ------------------------------------------------------------------
# Models
# ------------------------------------------------------------------
class Invoice(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    upload_id: str
    platform: str
    invoice_no: str
    invoice_date: str
    buyer_gstin: Optional[str] = None
    buyer_state_code: str
    hsn: str
    description: Optional[str] = None
    uqc: str = "PCS"
    qty: float = 0.0
    taxable_value: float
    rate: float
    cgst: float = 0.0
    sgst: float = 0.0
    igst: float = 0.0
    cess: float = 0.0
    is_ecom: bool = True
    is_b2b: bool = False
    exception: Optional[str] = None
    status: str = "flagged"  # flagged | corrected | ignored
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class UploadRecord(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    filename: str
    platform: str
    file_type: str
    size_bytes: int
    row_count: int = 0
    status: str = "processing"
    error: Optional[str] = None
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class ExceptionUpdate(BaseModel):
    status: Optional[str] = None
    hsn: Optional[str] = None
    rate: Optional[float] = None
    ims_status: Optional[str] = None  # accepted | rejected | pending

class ProfileUpdate(BaseModel):
    gstin: Optional[str] = None
    seller_state_code: Optional[str] = None
    business_name: Optional[str] = None
    filing_period: Optional[str] = None  # MMYYYY

class InterestCalcRequest(BaseModel):
    net_cash_liability: float
    days_delayed: int
    rate_pct: float = 18.0

class VendorInvoice(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    filename: str
    vendor_gstin: Optional[str] = None
    vendor_name: Optional[str] = None
    invoice_no: str
    invoice_date: str
    hsn: str = ""
    description: str = ""
    taxable_value: float = 0.0
    rate: float = 0.0
    cgst: float = 0.0
    sgst: float = 0.0
    igst: float = 0.0
    cess: float = 0.0
    itc_eligible: bool = True
    extraction_confidence: str = "medium"
    raw_extract: Optional[Dict[str, Any]] = None
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
def detect_platform(filename: str, columns: List[str]) -> str:
    name = filename.lower()
    cols = " ".join(c.lower() for c in columns)
    if "amazon" in name or "mtr" in cols or "asin" in cols:
        return "Amazon"
    if "flipkart" in name or "fsn" in cols or "voice" in name:
        return "Flipkart"
    if "meesho" in name or "sub_order_no" in cols or "supplier sku" in cols:
        return "Meesho"
    return "Unknown"

def norm_col(c: str) -> str:
    return re.sub(r"[^a-z0-9]", "", c.lower())

def find_col(cols: Dict[str, str], candidates: List[str]) -> Optional[str]:
    for cand in candidates:
        key = norm_col(cand)
        if key in cols:
            return cols[key]
    return None

def state_to_code(v: Any) -> str:
    if v is None:
        return "99"
    s = str(v).strip()
    if not s:
        return "99"
    # Already a 2-digit code
    if re.fullmatch(r"\d{1,2}", s):
        return s.zfill(2)
    code = STATE_NAME_TO_CODE.get(s.lower())
    if code:
        return code
    # partial match
    for name, k in STATE_NAME_TO_CODE.items():
        if name in s.lower() or s.lower() in name:
            return k
    return "99"

def safe_float(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or (isinstance(v, float) and pd.isna(v)):
            return default
        return float(str(v).replace(",", "").strip() or default)
    except Exception:
        return default

def r2(x: float) -> float:
    return round(x, 2)

def parse_dataframe(df: pd.DataFrame, platform: str, upload_id: str, seller_state: str) -> List[Invoice]:
    # Build column lookup normalized -> original
    col_map = {norm_col(c): c for c in df.columns}
    c_invno = find_col(col_map, ["invoice number", "invoice no", "invoiceno", "order id", "order-id", "sub_order_no", "suborderno", "orderid"])
    c_date = find_col(col_map, ["invoice date", "date", "order date", "orderdate", "invoicedate"])
    c_hsn = find_col(col_map, ["hsn", "hsn code", "hsn/sac", "hsnsac"])
    c_desc = find_col(col_map, ["description", "product", "item", "product name", "sku", "productname"])
    c_qty = find_col(col_map, ["qty", "quantity", "quantitysold"])
    c_txval = find_col(col_map, ["taxable value", "taxablevalue", "taxable amount", "net amount", "invoice amount", "principal amount", "grossamount", "sellingprice"])
    c_rate = find_col(col_map, ["tax rate", "gst rate", "rate", "taxrate", "gstpercent"])
    c_state = find_col(col_map, ["state", "ship to state", "shiptostate", "customerstate", "buyerstate", "shipstate", "endcustomerstate"])
    c_gstin = find_col(col_map, ["buyer gstin", "gstin", "customer gstin", "buyergstin"])
    c_cgst = find_col(col_map, ["cgst", "cgst amount", "cgstamount"])
    c_sgst = find_col(col_map, ["sgst", "sgst amount", "sgstamount", "utgst"])
    c_igst = find_col(col_map, ["igst", "igst amount", "igstamount"])
    c_uqc = find_col(col_map, ["uqc", "unit", "uom"])

    invoices: List[Invoice] = []
    for idx, row in df.iterrows():
        inv_no = str(row.get(c_invno) or f"AUTO-{idx+1}").strip() if c_invno else f"AUTO-{idx+1}"
        raw_date = row.get(c_date) if c_date else None
        try:
            date_str = pd.to_datetime(raw_date).strftime("%Y-%m-%d") if raw_date is not None and str(raw_date).strip() else datetime.now(timezone.utc).strftime("%Y-%m-%d")
        except Exception:
            date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        hsn = str(row.get(c_hsn) or "").strip() if c_hsn else ""
        # Clean HSN
        hsn = re.sub(r"[^0-9]", "", hsn) or ""
        desc = str(row.get(c_desc) or "").strip()[:60] if c_desc else ""
        qty = safe_float(row.get(c_qty) if c_qty else 1.0, 1.0)
        txval = safe_float(row.get(c_txval) if c_txval else 0.0)
        rate = safe_float(row.get(c_rate) if c_rate else 0.0)
        gstin = str(row.get(c_gstin) or "").strip().upper() if c_gstin else ""
        state_val = row.get(c_state) if c_state else None
        buyer_state = state_to_code(state_val)

        cgst_v = safe_float(row.get(c_cgst) if c_cgst else 0.0)
        sgst_v = safe_float(row.get(c_sgst) if c_sgst else 0.0)
        igst_v = safe_float(row.get(c_igst) if c_igst else 0.0)

        # Compute tax if missing
        if rate == 0 and (cgst_v + sgst_v + igst_v) > 0 and txval > 0:
            rate = round((cgst_v + sgst_v + igst_v) / txval * 100, 2)
        if (cgst_v + sgst_v + igst_v) == 0 and rate > 0 and txval > 0:
            if buyer_state == seller_state:
                cgst_v = r2(txval * rate / 200)
                sgst_v = cgst_v
                igst_v = 0.0
            else:
                igst_v = r2(txval * rate / 100)
                cgst_v = 0.0
                sgst_v = 0.0
        cgst_v, sgst_v, igst_v = r2(cgst_v), r2(sgst_v), r2(igst_v)

        # Exceptions
        exc = None
        if not hsn or len(hsn) < 4:
            exc = "HSN missing or invalid (must be 4/6/8 digits)"
        elif txval <= 0:
            exc = "Taxable value is zero or negative"
        elif rate not in (0, 0.1, 0.25, 1, 1.5, 3, 5, 6, 7.5, 12, 18, 28):
            exc = f"Non-standard tax rate: {rate}%"
        elif buyer_state == "99":
            exc = "Buyer state not recognized"
        elif buyer_state == seller_state and igst_v > 0:
            exc = "Intra-state transaction has IGST — expected CGST+SGST"
        elif buyer_state != seller_state and (cgst_v > 0 or sgst_v > 0):
            exc = "Inter-state transaction has CGST/SGST — expected IGST"

        # Validate GSTIN
        is_b2b = bool(gstin and GSTIN_RE.match(gstin))

        inv = Invoice(
            upload_id=upload_id,
            platform=platform,
            invoice_no=inv_no,
            invoice_date=date_str,
            buyer_gstin=gstin if is_b2b else None,
            buyer_state_code=buyer_state,
            hsn=hsn or "N/A",
            description=desc,
            uqc=str(row.get(c_uqc) or "PCS")[:5].upper() if c_uqc else "PCS",
            qty=qty,
            taxable_value=r2(txval),
            rate=rate,
            cgst=cgst_v,
            sgst=sgst_v,
            igst=igst_v,
            is_b2b=is_b2b,
            is_ecom=True,
            exception=exc,
            status="flagged" if exc else "corrected",
        )
        invoices.append(inv)
    return invoices

# ------------------------------------------------------------------
# GSTR Compilation
# ------------------------------------------------------------------
def compile_gstr1(invoices: List[Dict[str, Any]], gstin: str, period: str) -> Dict[str, Any]:
    b2b_map: Dict[str, Any] = defaultdict(lambda: {"inv": []})
    b2c_map: Dict[str, Any] = defaultdict(lambda: {"txval": 0.0, "iamt": 0.0, "camt": 0.0, "samt": 0.0, "count": 0})
    hsn_map: Dict[tuple, Any] = defaultdict(lambda: {"qty": 0.0, "txval": 0.0, "iamt": 0.0, "camt": 0.0, "samt": 0.0, "csamt": 0.0, "desc": ""})
    ecom_b2c: Dict[tuple, Any] = defaultdict(lambda: {"txval": 0.0, "iamt": 0.0, "camt": 0.0, "samt": 0.0})

    for inv in invoices:
        if inv.get("status") == "ignored":
            continue
        hsn = inv["hsn"]
        rate = float(inv["rate"])
        key = (hsn, rate)
        hsn_map[key]["qty"] += float(inv["qty"])
        hsn_map[key]["txval"] += float(inv["taxable_value"])
        hsn_map[key]["iamt"] += float(inv["igst"])
        hsn_map[key]["camt"] += float(inv["cgst"])
        hsn_map[key]["samt"] += float(inv["sgst"])
        hsn_map[key]["desc"] = inv.get("description") or hsn_map[key]["desc"]

        if inv["is_b2b"] and inv.get("buyer_gstin"):
            b2b_map[inv["buyer_gstin"]]["inv"].append(inv)
        else:
            skey = (inv["buyer_state_code"], rate)
            b2c_map[skey]["txval"] += float(inv["taxable_value"])
            b2c_map[skey]["iamt"] += float(inv["igst"])
            b2c_map[skey]["camt"] += float(inv["cgst"])
            b2c_map[skey]["samt"] += float(inv["sgst"])
            b2c_map[skey]["count"] += 1
            if inv.get("is_ecom"):
                ecom_b2c[skey]["txval"] += float(inv["taxable_value"])
                ecom_b2c[skey]["iamt"] += float(inv["igst"])
                ecom_b2c[skey]["camt"] += float(inv["cgst"])
                ecom_b2c[skey]["samt"] += float(inv["sgst"])

    # Table 4 (B2B)
    b2b = []
    for gst, data in b2b_map.items():
        inv_list = []
        for i in data["inv"]:
            inv_list.append({
                "inum": i["invoice_no"],
                "idt": i["invoice_date"],
                "val": r2(i["taxable_value"] + i["cgst"] + i["sgst"] + i["igst"]),
                "pos": i["buyer_state_code"],
                "rchrg": "N",
                "itms": [{
                    "num": 1,
                    "itm_det": {
                        "txval": r2(i["taxable_value"]),
                        "rt": i["rate"],
                        "iamt": r2(i["igst"]),
                        "camt": r2(i["cgst"]),
                        "samt": r2(i["sgst"]),
                        "csamt": 0.0,
                    },
                }],
            })
        b2b.append({"ctin": gst, "inv": inv_list})

    # Table 7 (B2C small aggregated by state+rate)
    b2cs = []
    for (state, rate), v in b2c_map.items():
        b2cs.append({
            "sply_ty": "INTRA" if state == SELLER_STATE_CODE_DEFAULT else "INTER",
            "pos": state,
            "typ": "OE",
            "txval": r2(v["txval"]),
            "rt": rate,
            "iamt": r2(v["iamt"]),
            "camt": r2(v["camt"]),
            "samt": r2(v["samt"]),
            "csamt": 0.0,
        })

    # Table 12 (HSN Summary)
    hsn_arr = []
    for i, ((hsn, rate), v) in enumerate(sorted(hsn_map.items()), start=1):
        hsn_arr.append({
            "num": i,
            "hsn_sc": hsn,
            "desc": (v["desc"] or "")[:30],
            "uqc": "PCS",
            "qty": r2(v["qty"]),
            "txval": r2(v["txval"]),
            "rt": rate,
            "iamt": r2(v["iamt"]),
            "camt": r2(v["camt"]),
            "samt": r2(v["samt"]),
            "csamt": r2(v["csamt"]),
        })

    hsn_str = json.dumps(hsn_arr, sort_keys=True)
    chksum = hashlib.sha256(hsn_str.encode()).hexdigest()[:32]

    # Table 14 (E-comm operator supplies — B2C aggregate)
    ecom14 = []
    for (state, rate), v in ecom_b2c.items():
        ecom14.append({
            "pos": state,
            "rt": rate,
            "txval": r2(v["txval"]),
            "iamt": r2(v["iamt"]),
            "camt": r2(v["camt"]),
            "samt": r2(v["samt"]),
        })

    return {
        "gstin": gstin,
        "fp": period,
        "version": "GST3.0.4",
        "hash": "hash",
        "b2b": b2b,
        "b2cs": b2cs,
        "hsn": {"chksum": chksum, "data": hsn_arr},
        "supeco": {"clttx": ecom14},
    }

def compile_gstr3b(invoices: List[Dict[str, Any]], vendor_invoices: List[Dict[str, Any]], gstin: str, period: str) -> Dict[str, Any]:
    total_txval = 0.0
    total_iamt = 0.0
    total_camt = 0.0
    total_samt = 0.0
    for inv in invoices:
        if inv.get("status") == "ignored":
            continue
        total_txval += float(inv["taxable_value"])
        total_iamt += float(inv["igst"])
        total_camt += float(inv["cgst"])
        total_samt += float(inv["sgst"])
    itc_iamt = itc_camt = itc_samt = 0.0
    for vi in vendor_invoices:
        if not vi.get("itc_eligible", True):
            continue
        itc_iamt += float(vi.get("igst", 0))
        itc_camt += float(vi.get("cgst", 0))
        itc_samt += float(vi.get("sgst", 0))
    return {
        "gstin": gstin,
        "ret_period": period,
        "sup_details": {
            "osup_det": {
                "txval": r2(total_txval),
                "iamt": r2(total_iamt),
                "camt": r2(total_camt),
                "samt": r2(total_samt),
                "csamt": 0.0,
            }
        },
        "itc_elg": {
            "itc_avl": [
                {"ty": "IMPG", "iamt": 0, "camt": 0, "samt": 0, "csamt": 0},
                {"ty": "OTH", "iamt": r2(itc_iamt), "camt": r2(itc_camt), "samt": r2(itc_samt), "csamt": 0},
            ],
            "itc_net": {"iamt": r2(itc_iamt), "camt": r2(itc_camt), "samt": r2(itc_samt), "csamt": 0},
        },
    }

async def extract_pdf_with_llm(pdf_bytes: bytes, filename: str) -> Dict[str, Any]:
    """Extract vendor invoice fields from PDF using Claude Sonnet with structured JSON output."""
    reader = PdfReader(io.BytesIO(pdf_bytes))
    text = "\n".join((p.extract_text() or "") for p in reader.pages)[:12000]
    if not text.strip():
        raise ValueError("PDF has no extractable text (scanned image?)")

    key = os.environ.get("EMERGENT_LLM_KEY")
    if not key:
        raise ValueError("EMERGENT_LLM_KEY not configured")

    system_msg = (
        "You are a GST invoice data extraction engine. Extract fields from Indian vendor invoice text. "
        "Return STRICT JSON only, no markdown, no prose. Schema: "
        '{"invoice_no":"string","invoice_date":"YYYY-MM-DD","vendor_gstin":"15-char GSTIN or null",'
        '"vendor_name":"string","hsn":"digits only","description":"short","taxable_value":number,'
        '"rate":number (GST%),"cgst":number,"sgst":number,"igst":number,"cess":number,"confidence":"high|medium|low"}. '
        "If a field is not present, use empty string or 0. Never invent GSTINs."
    )
    chat = LlmChat(api_key=key, session_id=f"pdf-{uuid.uuid4().hex[:8]}", system_message=system_msg).with_model("anthropic", "claude-sonnet-4-5-20250929")
    resp = await chat.send_message(UserMessage(text=f"Extract invoice from this text:\n\n{text}\n\nReturn JSON only."))
    txt = str(resp).strip()
    # Strip code fences if any
    txt = re.sub(r"^```(?:json)?\s*|\s*```$", "", txt.strip(), flags=re.MULTILINE)
    m = re.search(r"\{.*\}", txt, re.DOTALL)
    if not m:
        raise ValueError(f"LLM returned non-JSON: {txt[:200]}")
    return json.loads(m.group(0))

# ------------------------------------------------------------------
# Routes
# ------------------------------------------------------------------
# ------------------------------------------------------------------
# Auth (Emergent-managed Google OAuth)
# ------------------------------------------------------------------
async def get_current_user(session_token: Optional[str] = Cookie(None)):
    if not session_token:
        return None
    sess = await db.sessions.find_one({"session_token": session_token}, {"_id": 0})
    if not sess:
        return None
    if datetime.fromisoformat(sess["expires_at"]) < datetime.now(timezone.utc):
        return None
    user = await db.users.find_one({"id": sess["user_id"]}, {"_id": 0})
    return user

@api_router.post("/auth/session")
async def create_session(request: Request, response: Response):
    body = await request.json()
    sid = body.get("session_id")
    if not sid:
        raise HTTPException(status_code=400, detail="session_id required")
    async with httpx.AsyncClient(timeout=15) as ac:
        r = await ac.get(
            "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data",
            headers={"X-Session-ID": sid},
        )
    if r.status_code != 200:
        raise HTTPException(status_code=401, detail=f"Auth failed: {r.text[:200]}")
    data = r.json()
    email = data["email"]
    now = datetime.now(timezone.utc)
    user = await db.users.find_one({"email": email}, {"_id": 0})
    if not user:
        user = {
            "id": str(uuid.uuid4()),
            "email": email,
            "name": data.get("name", ""),
            "picture": data.get("picture", ""),
            "created_at": now.isoformat(),
        }
        await db.users.insert_one(user)
    session_token = data["session_token"]
    await db.sessions.insert_one({
        "session_token": session_token,
        "user_id": user["id"],
        "expires_at": (now + timedelta(days=7)).isoformat(),
        "created_at": now.isoformat(),
    })
    response.set_cookie(
        key="session_token", value=session_token,
        httponly=True, secure=True, samesite="none",
        max_age=7 * 24 * 3600, path="/",
    )
    return {"user": user}

@api_router.get("/auth/me")
async def get_me(user=Depends(get_current_user)):
    return {"user": user}

@api_router.post("/auth/logout")
async def logout(response: Response, session_token: Optional[str] = Cookie(None)):
    if session_token:
        await db.sessions.delete_one({"session_token": session_token})
    response.delete_cookie("session_token", path="/", samesite="none", secure=True)
    return {"ok": True}

# ------------------------------------------------------------------
# Profile
# ------------------------------------------------------------------
async def get_active_profile(user) -> Dict[str, Any]:
    if user:
        p = await db.profiles.find_one({"user_id": user["id"]}, {"_id": 0})
        if p:
            return p
    return {"gstin": "27AABCU9603R1ZX", "seller_state_code": SELLER_STATE_CODE_DEFAULT, "business_name": "Demo Seller", "filing_period": datetime.now(timezone.utc).strftime("%m%Y")}

@api_router.get("/profile")
async def get_profile(user=Depends(get_current_user)):
    return await get_active_profile(user)

@api_router.put("/profile")
async def update_profile(upd: ProfileUpdate, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    if upd.gstin and not GSTIN_RE.match(upd.gstin.upper()):
        raise HTTPException(status_code=400, detail="Invalid GSTIN format")
    if upd.filing_period and not re.fullmatch(r"\d{6}", upd.filing_period):
        raise HTTPException(status_code=400, detail="filing_period must be MMYYYY")
    changes = {k: v for k, v in upd.model_dump().items() if v is not None}
    changes["user_id"] = user["id"]
    changes["updated_at"] = datetime.now(timezone.utc).isoformat()
    await db.profiles.update_one({"user_id": user["id"]}, {"$set": changes}, upsert=True)
    return await db.profiles.find_one({"user_id": user["id"]}, {"_id": 0})

# ------------------------------------------------------------------
# Interest estimator (Rule 88B — 18% p.a. on net cash shortfall)
# ------------------------------------------------------------------
@api_router.post("/interest")
async def calc_interest(req: InterestCalcRequest):
    if req.net_cash_liability < 0 or req.days_delayed < 0:
        raise HTTPException(status_code=400, detail="Amounts must be non-negative")
    interest = req.net_cash_liability * (req.rate_pct / 100.0) * (req.days_delayed / 365.0)
    return {
        "net_cash_liability": r2(req.net_cash_liability),
        "days_delayed": req.days_delayed,
        "rate_pct": req.rate_pct,
        "interest": r2(interest),
        "total_payable": r2(req.net_cash_liability + interest),
        "rule": "Rule 88B(1) — interest on net cash tax shortfall",
    }

@api_router.get("/")
async def root():
    return {"message": "GST-ECOM-EZ API"}

@api_router.post("/uploads")
async def upload_file(
    file: UploadFile = File(...),
    seller_state: str = Form(SELLER_STATE_CODE_DEFAULT),
):
    name = file.filename or "upload"
    contents = await file.read()
    size = len(contents)
    ext = name.lower().rsplit(".", 1)[-1] if "." in name else ""

    if ext not in ("csv", "xlsx", "xls"):
        raise HTTPException(status_code=400, detail=f"Unsupported file type .{ext}. Use CSV or XLSX.")

    try:
        if ext == "csv":
            df = pd.read_csv(io.BytesIO(contents), dtype=str, keep_default_na=False)
        else:
            df = pd.read_excel(io.BytesIO(contents), dtype=str)
        df = df.fillna("")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to parse: {e}")

    platform = detect_platform(name, list(df.columns))
    upload = UploadRecord(
        filename=name, platform=platform, file_type=ext,
        size_bytes=size, row_count=len(df), status="processing",
    )
    await db.uploads.insert_one(upload.model_dump())

    try:
        invoices = parse_dataframe(df, platform, upload.id, seller_state or SELLER_STATE_CODE_DEFAULT)
        if invoices:
            await db.invoices.insert_many([i.model_dump() for i in invoices])
        upload.status = "completed"
        await db.uploads.update_one({"id": upload.id}, {"$set": {"status": "completed"}})
        return {
            "upload_id": upload.id,
            "filename": name,
            "platform": platform,
            "rows_parsed": len(invoices),
            "exceptions": sum(1 for i in invoices if i.exception),
        }
    except Exception as e:
        await db.uploads.update_one({"id": upload.id}, {"$set": {"status": "failed", "error": str(e)}})
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/uploads")
async def list_uploads():
    docs = await db.uploads.find({}, {"_id": 0}).sort("created_at", -1).to_list(200)
    return docs

@api_router.get("/invoices")
async def list_invoices(status: Optional[str] = None, platform: Optional[str] = None, limit: int = 500):
    q: Dict[str, Any] = {}
    if status:
        q["status"] = status
    if platform:
        q["platform"] = platform
    docs = await db.invoices.find(q, {"_id": 0}).sort("created_at", -1).to_list(limit)
    return docs

@api_router.get("/exceptions")
async def list_exceptions(limit: int = 500):
    docs = await db.invoices.find({"exception": {"$ne": None}}, {"_id": 0}).sort("created_at", -1).to_list(limit)
    return docs

@api_router.patch("/invoices/{invoice_id}")
async def update_invoice(invoice_id: str, upd: ExceptionUpdate):
    changes: Dict[str, Any] = {}
    if upd.status:
        changes["status"] = upd.status
        if upd.status in ("corrected", "ignored"):
            changes["exception"] = None
    if upd.hsn:
        changes["hsn"] = re.sub(r"[^0-9]", "", upd.hsn) or upd.hsn
    if upd.rate is not None:
        changes["rate"] = upd.rate
        # Recompute
        inv = await db.invoices.find_one({"id": invoice_id}, {"_id": 0})
        if inv:
            txval = float(inv["taxable_value"])
            if inv["buyer_state_code"] == SELLER_STATE_CODE_DEFAULT:
                changes["cgst"] = r2(txval * upd.rate / 200)
                changes["sgst"] = r2(txval * upd.rate / 200)
                changes["igst"] = 0.0
            else:
                changes["igst"] = r2(txval * upd.rate / 100)
                changes["cgst"] = 0.0
                changes["sgst"] = 0.0
    if upd.ims_status:
        if upd.ims_status not in ("accepted", "rejected", "pending"):
            raise HTTPException(status_code=400, detail="ims_status must be accepted|rejected|pending")
        changes["ims_status"] = upd.ims_status
    if not changes:
        raise HTTPException(status_code=400, detail="No changes")
    res = await db.invoices.update_one({"id": invoice_id}, {"$set": changes})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Not found")
    doc = await db.invoices.find_one({"id": invoice_id}, {"_id": 0})
    return doc

@api_router.get("/stats")
async def stats():
    uploads = await db.uploads.count_documents({})
    invoices = await db.invoices.count_documents({})
    exceptions = await db.invoices.count_documents({"exception": {"$ne": None}, "status": "flagged"})
    ready = await db.invoices.count_documents({"status": "corrected"})
    total_txval = 0.0
    total_tax = 0.0
    async for inv in db.invoices.find({"status": {"$ne": "ignored"}}, {"_id": 0, "taxable_value": 1, "cgst": 1, "sgst": 1, "igst": 1}):
        total_txval += float(inv.get("taxable_value", 0))
        total_tax += float(inv.get("cgst", 0)) + float(inv.get("sgst", 0)) + float(inv.get("igst", 0))
    return {
        "documents_uploaded": uploads,
        "invoices_extracted": invoices,
        "exceptions_flagged": exceptions,
        "returns_ready": 1 if ready > 0 else 0,
        "total_taxable_value": r2(total_txval),
        "total_tax": r2(total_tax),
    }

@api_router.get("/compliance/gstr1")
async def get_gstr1(gstin: str = "27AABCU9603R1ZX", period: str = None):
    if not period:
        period = datetime.now(timezone.utc).strftime("%m%Y")
    invoices = await db.invoices.find({"status": {"$ne": "ignored"}}, {"_id": 0}).to_list(10000)
    payload = compile_gstr1(invoices, gstin, period)
    return payload

@api_router.get("/compliance/gstr3b")
async def get_gstr3b(gstin: str = "27AABCU9603R1ZX", period: str = None):
    if not period:
        period = datetime.now(timezone.utc).strftime("%m%Y")
    invoices = await db.invoices.find({"status": {"$ne": "ignored"}}, {"_id": 0}).to_list(10000)
    vendors = await db.vendor_invoices.find({}, {"_id": 0}).to_list(10000)
    return compile_gstr3b(invoices, vendors, gstin, period)

@api_router.post("/vendor-invoices")
async def upload_vendor_pdf(file: UploadFile = File(...)):
    name = file.filename or "vendor.pdf"
    if not name.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files supported for vendor invoices")
    contents = await file.read()
    upload = UploadRecord(filename=name, platform="Vendor", file_type="pdf", size_bytes=len(contents), row_count=0, status="processing")
    await db.uploads.insert_one(upload.model_dump())
    try:
        data = await extract_pdf_with_llm(contents, name)
        vi = VendorInvoice(
            filename=name,
            vendor_gstin=(data.get("vendor_gstin") or None) or None,
            vendor_name=str(data.get("vendor_name") or "")[:100],
            invoice_no=str(data.get("invoice_no") or f"VEND-{uuid.uuid4().hex[:6]}"),
            invoice_date=str(data.get("invoice_date") or datetime.now(timezone.utc).strftime("%Y-%m-%d")),
            hsn=re.sub(r"[^0-9]", "", str(data.get("hsn") or "")),
            description=str(data.get("description") or "")[:100],
            taxable_value=safe_float(data.get("taxable_value"), 0.0),
            rate=safe_float(data.get("rate"), 0.0),
            cgst=safe_float(data.get("cgst"), 0.0),
            sgst=safe_float(data.get("sgst"), 0.0),
            igst=safe_float(data.get("igst"), 0.0),
            cess=safe_float(data.get("cess"), 0.0),
            extraction_confidence=str(data.get("confidence") or "medium"),
            raw_extract=data,
        )
        # Validate vendor GSTIN — block ITC on missing/malformed
        if not vi.vendor_gstin or not GSTIN_RE.match(vi.vendor_gstin.upper()):
            vi.vendor_gstin = None
            vi.itc_eligible = False
        await db.vendor_invoices.insert_one(vi.model_dump())
        await db.uploads.update_one({"id": upload.id}, {"$set": {"status": "completed", "row_count": 1}})
        return {"upload_id": upload.id, "vendor_invoice_id": vi.id, "extracted": vi.model_dump()}
    except Exception as e:
        logger.exception("PDF extraction failed")
        await db.uploads.update_one({"id": upload.id}, {"$set": {"status": "failed", "error": str(e)}})
        raise HTTPException(status_code=500, detail=f"Extraction failed: {e}")

@api_router.get("/vendor-invoices")
async def list_vendor_invoices():
    return await db.vendor_invoices.find({}, {"_id": 0}).sort("created_at", -1).to_list(500)

@api_router.delete("/reset")
async def reset_all():
    await db.uploads.delete_many({})
    await db.invoices.delete_many({})
    await db.vendor_invoices.delete_many({})
    return {"ok": True}

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
