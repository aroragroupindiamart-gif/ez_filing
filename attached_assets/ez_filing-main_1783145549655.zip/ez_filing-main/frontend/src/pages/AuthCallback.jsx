import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { Loader2 } from "lucide-react";

export default function AuthCallback() {
  const nav = useNavigate();
  const { refresh } = useAuth();

  useEffect(() => {
    const hash = window.location.hash;
    const m = hash.match(/session_id=([^&]+)/);
    if (!m) {
      toast.error("No session_id in URL");
      nav("/", { replace: true });
      return;
    }
    (async () => {
      try {
        await api.post("/auth/session", { session_id: m[1] }, { withCredentials: true });
        await refresh();
        toast.success("Signed in");
        nav("/dashboard/profile", { replace: true });
      } catch (e) {
        toast.error("Auth failed: " + (e.response?.data?.detail || e.message));
        nav("/", { replace: true });
      }
    })();
  }, []);

  return (
    <div className="min-h-screen bg-gst-bg flex items-center justify-center" data-testid="auth-callback">
      <div className="text-center">
        <Loader2 size={32} className="mx-auto text-gst-amber animate-spin mb-4" />
        <p className="text-sm text-gst-text-secondary">Completing sign-in…</p>
      </div>
    </div>
  );
}
