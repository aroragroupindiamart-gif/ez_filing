import Navigation from "../components/Navigation";
import Footer from "../components/Footer";
import HeroSection from "../sections/HeroSection";
import PlatformBar from "../sections/PlatformBar";
import ProblemSection from "../sections/ProblemSection";
import DemoSection from "../sections/DemoSection";
import FeatureGrid from "../sections/FeatureGrid";
import StatsBand from "../sections/StatsBand";
import PricingSection from "../sections/PricingSection";

export default function Home() {
  return (
    <div className="min-h-screen bg-gst-bg" data-testid="home-page">
      <Navigation />
      <main>
        <HeroSection />
        <PlatformBar />
        <ProblemSection />
        <DemoSection />
        <FeatureGrid />
        <StatsBand />
        <PricingSection />
      </main>
      <Footer />
    </div>
  );
}
