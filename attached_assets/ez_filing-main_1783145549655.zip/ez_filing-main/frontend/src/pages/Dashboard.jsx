import { Routes, Route, Navigate } from "react-router-dom";
import { Bell, HelpCircle, User } from "lucide-react";
import DashboardSidebar from "../dashboard/DashboardSidebar";
import FileControlCenter from "../dashboard/FileControlCenter";
import ExceptionLedger from "../dashboard/ExceptionLedger";
import CompliancePreview from "../dashboard/CompliancePreview";
import VendorDocuments from "../dashboard/VendorDocuments";
import Profile from "../dashboard/Profile";
import InterestCalculator from "../dashboard/InterestCalculator";
import { useAuth, logout, loginWithGoogle } from "../lib/auth";
import { LogIn, LogOut } from "lucide-react";

function TopBar({ title }) {
  const { user, refresh } = useAuth();
  const doLogout = async () => { await logout(); await refresh(); };
  return (
    <header className="h-14 bg-gst-bg border-b border-gst-border-default flex items-center justify-between px-6 flex-shrink-0">
      <div className="text-sm text-gst-text-secondary">
        <span className="text-gst-text-muted">Workspace</span>
        <span className="mx-2 text-gst-border-default">/</span>
        <span className="text-gst-text">{title}</span>
      </div>
      <div className="flex items-center gap-3">
        <button className="relative p-2 text-gst-text-secondary hover:text-gst-text">
          <Bell size={18} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-gst-amber rounded-full" />
        </button>
        <button className="p-2 text-gst-text-secondary hover:text-gst-text"><HelpCircle size={18} /></button>
        {user ? (
          <button data-testid="logout-btn" onClick={doLogout} className="flex items-center gap-2 px-3 py-1.5 text-xs text-gst-text-secondary border border-gst-border-default hover:text-gst-text">
            <LogOut size={12} /> {user.name?.split(" ")[0] || "Sign out"}
          </button>
        ) : (
          <button data-testid="nav-login-btn" onClick={loginWithGoogle} className="flex items-center gap-2 px-3 py-1.5 text-xs bg-gst-amber text-gst-text-light hover:brightness-110">
            <LogIn size={12} /> Sign in
          </button>
        )}
      </div>
    </header>
  );
}

function Layout({ title, children }) {
  return (
    <div className="min-h-screen bg-gst-bg" data-testid="dashboard-layout">
      <DashboardSidebar />
      <div className="ml-60 flex flex-col min-h-screen">
        <TopBar title={title} />
        <main className="flex-1 p-6 overflow-auto">{children}</main>
      </div>
    </div>
  );
}

function Placeholder({ title }) {
  return (
    <Layout title={title}>
      <div className="flex items-center justify-center h-64 border border-gst-border-default bg-gst-surface">
        <p className="text-gst-text-muted text-sm">{title} — coming soon</p>
      </div>
    </Layout>
  );
}

export default function Dashboard() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/dashboard/files" replace />} />
      <Route path="/files" element={<Layout title="File Control Center"><FileControlCenter /></Layout>} />
      <Route path="/exceptions" element={<Layout title="Exception Ledger"><ExceptionLedger /></Layout>} />
      <Route path="/compliance" element={<Layout title="Compliance Preview"><div className="space-y-6"><CompliancePreview /><InterestCalculator /></div></Layout>} />
      <Route path="/invoices" element={<Placeholder title="Invoices" />} />
      <Route path="/reports" element={<Placeholder title="Marketplace Reports" />} />
      <Route path="/documents" element={<Layout title="Vendor Documents"><VendorDocuments /></Layout>} />
      <Route path="/profile" element={<Layout title="GST Profile"><Profile /></Layout>} />
      <Route path="/team" element={<Placeholder title="Team" />} />
      <Route path="/billing" element={<Placeholder title="Billing" />} />
    </Routes>
  );
}
