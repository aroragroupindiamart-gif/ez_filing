import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Download, Check, Copy, ChevronDown, ChevronUp } from "lucide-react";
import { fetchGSTR1, fetchGSTR3B } from "../lib/api";

const gstr1Tables = [
  { id: "b2b", name: "4. B2B Invoices" },
  { id: "b2cs", name: "7. B2C (Small)" },
  { id: "hsn", name: "12. HSN Summary" },
  { id: "supeco", name: "14/15. E-comm" },
];

export default function CompliancePreview() {
  const [tab, setTab] = useState("gstr1");
  const [table, setTable] = useState("hsn");
  const [g1, setG1] = useState(null);
  const [g3b, setG3b] = useState(null);
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [a, b] = await Promise.all([fetchGSTR1(), fetchGSTR3B()]);
        setG1(a); setG3b(b);
      } catch (e) { toast.error(e.message); }
    })();
  }, []);

  const active = tab === "gstr1" ? g1 : g3b;
  const jsonStr = active ? JSON.stringify(active, null, 2) : "";

  const copy = () => {
    navigator.clipboard.writeText(jsonStr);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const download = () => {
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${tab}_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Downloaded");
  };

  const hsn = g1?.hsn?.data || [];
  const b2b = g1?.b2b || [];
  const b2cs = g1?.b2cs || [];
  const eco = g1?.supeco?.clttx || [];

  const totalTx = hsn.reduce((s, r) => s + Number(r.txval || 0), 0);
  const totalTax = hsn.reduce((s, r) => s + Number(r.iamt || 0) + Number(r.camt || 0) + Number(r.samt || 0), 0);

  return (
    <div className="space-y-4" data-testid="compliance-preview">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex">
          <button data-testid="tab-gstr1" onClick={() => setTab("gstr1")} className={`px-5 py-2.5 text-sm font-medium border-b-2 ${tab === "gstr1" ? "border-gst-amber text-gst-text" : "border-transparent text-gst-text-muted hover:text-gst-text-secondary"}`}>GSTR-1</button>
          <button data-testid="tab-gstr3b" onClick={() => setTab("gstr3b")} className={`px-5 py-2.5 text-sm font-medium border-b-2 ${tab === "gstr3b" ? "border-gst-amber text-gst-text" : "border-transparent text-gst-text-muted hover:text-gst-text-secondary"}`}>GSTR-3B</button>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 px-4 py-2 border border-gst-border-default text-xs text-gst-text-secondary hover:text-gst-text">
            <Check size={12} /> Validate
          </button>
          <button data-testid="download-json-btn" onClick={download} className="flex items-center gap-1.5 px-4 py-2 bg-gst-amber text-gst-text-light text-xs font-medium hover:brightness-110">
            <Download size={12} /> Download JSON
          </button>
        </div>
      </div>

      {tab === "gstr1" ? (
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="lg:w-48 flex-shrink-0">
            <div className="bg-gst-surface border border-gst-border-default">
              {gstr1Tables.map((t) => (
                <button
                  key={t.id}
                  data-testid={`gstr1-table-${t.id}`}
                  onClick={() => setTable(t.id)}
                  className={`w-full text-left px-4 py-3 text-xs transition-colors ${table === t.id ? "border-l-[3px] border-l-gst-amber bg-gst-surface-el text-gst-text" : "text-gst-text-muted hover:text-gst-text-secondary hover:bg-gst-surface-el/50"}`}
                >
                  {t.name}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 min-w-0">
            <div className="bg-gst-surface border border-gst-border-default overflow-auto scrollbar-thin">
              {table === "hsn" && (
                <table className="w-full">
                  <thead className="bg-gst-surface-el">
                    <tr>
                      {["#", "HSN", "Description", "UQC", "Qty", "Taxable", "Rate%", "IGST", "CGST", "SGST", "Cess"].map((h) => (
                        <th key={h} className="h-9 px-2 text-left text-[10px] font-medium uppercase tracking-wider text-gst-text-muted">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {hsn.length === 0 && <tr><td colSpan={11} className="p-8 text-center text-sm text-gst-text-muted">No data yet</td></tr>}
                    {hsn.map((r) => (
                      <tr key={`hsn-${r.hsn_sc}-${r.rt}`} className={r.num % 2 === 0 ? "bg-gst-row-stripe" : ""}>
                        <td className="px-2 py-2 font-mono-data text-xs text-gst-text">{r.num}</td>
                        <td className="px-2 py-2 font-mono-data text-xs text-gst-text">{r.hsn_sc}</td>
                        <td className="px-2 py-2 text-xs text-gst-text-secondary truncate max-w-[160px]">{r.desc}</td>
                        <td className="px-2 py-2 font-mono-data text-xs text-gst-text-muted">{r.uqc}</td>
                        <td className="px-2 py-2 font-mono-data text-xs text-gst-text text-right">{r.qty}</td>
                        <td className="px-2 py-2 font-mono-data text-xs text-gst-text text-right">{r.txval.toFixed(2)}</td>
                        <td className="px-2 py-2 font-mono-data text-xs text-gst-amber text-right">{r.rt}</td>
                        <td className="px-2 py-2 font-mono-data text-xs text-gst-text text-right">{r.iamt.toFixed(2)}</td>
                        <td className="px-2 py-2 font-mono-data text-xs text-gst-text text-right">{r.camt.toFixed(2)}</td>
                        <td className="px-2 py-2 font-mono-data text-xs text-gst-text text-right">{r.samt.toFixed(2)}</td>
                        <td className="px-2 py-2 font-mono-data text-xs text-gst-text text-right">{r.csamt.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
              {table === "b2b" && (
                <table className="w-full">
                  <thead className="bg-gst-surface-el"><tr>{["GSTIN", "Invoices"].map((h) => <th key={h} className="h-9 px-3 text-left text-[10px] uppercase tracking-wider text-gst-text-muted">{h}</th>)}</tr></thead>
                  <tbody>
                    {b2b.length === 0 && <tr><td colSpan={2} className="p-8 text-center text-sm text-gst-text-muted">No B2B invoices</td></tr>}
                    {b2b.map((r) => (
                      <tr key={r.ctin}><td className="px-3 py-2 font-mono-data text-xs text-gst-text">{r.ctin}</td><td className="px-3 py-2 text-xs text-gst-text-secondary">{r.inv.length} invoice(s)</td></tr>
                    ))}
                  </tbody>
                </table>
              )}
              {table === "b2cs" && (
                <table className="w-full">
                  <thead className="bg-gst-surface-el"><tr>{["Supply", "PoS", "Type", "Taxable", "Rate%", "IGST", "CGST", "SGST"].map((h) => <th key={h} className="h-9 px-3 text-left text-[10px] uppercase tracking-wider text-gst-text-muted">{h}</th>)}</tr></thead>
                  <tbody>
                    {b2cs.length === 0 && <tr><td colSpan={8} className="p-8 text-center text-sm text-gst-text-muted">No B2C entries</td></tr>}
                    {b2cs.map((r, i) => (
                      <tr key={`b2cs-${r.pos}-${r.rt}`} className={i % 2 === 1 ? "bg-gst-row-stripe" : ""}>
                        <td className="px-3 py-2 text-xs text-gst-text">{r.sply_ty}</td>
                        <td className="px-3 py-2 font-mono-data text-xs text-gst-text">{r.pos}</td>
                        <td className="px-3 py-2 text-xs text-gst-text-muted">{r.typ}</td>
                        <td className="px-3 py-2 font-mono-data text-xs text-gst-text text-right">{r.txval.toFixed(2)}</td>
                        <td className="px-3 py-2 font-mono-data text-xs text-gst-amber text-right">{r.rt}</td>
                        <td className="px-3 py-2 font-mono-data text-xs text-gst-text text-right">{r.iamt.toFixed(2)}</td>
                        <td className="px-3 py-2 font-mono-data text-xs text-gst-text text-right">{r.camt.toFixed(2)}</td>
                        <td className="px-3 py-2 font-mono-data text-xs text-gst-text text-right">{r.samt.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
              {table === "supeco" && (
                <table className="w-full">
                  <thead className="bg-gst-surface-el"><tr>{["PoS", "Rate%", "Taxable", "IGST", "CGST", "SGST"].map((h) => <th key={h} className="h-9 px-3 text-left text-[10px] uppercase tracking-wider text-gst-text-muted">{h}</th>)}</tr></thead>
                  <tbody>
                    {eco.length === 0 && <tr><td colSpan={6} className="p-8 text-center text-sm text-gst-text-muted">No e-comm supplies</td></tr>}
                    {eco.map((r, i) => (
                      <tr key={`eco-${r.pos}-${r.rt}`} className={i % 2 === 1 ? "bg-gst-row-stripe" : ""}>
                        <td className="px-3 py-2 font-mono-data text-xs text-gst-text">{r.pos}</td>
                        <td className="px-3 py-2 font-mono-data text-xs text-gst-amber">{r.rt}</td>
                        <td className="px-3 py-2 font-mono-data text-xs text-gst-text text-right">{r.txval.toFixed(2)}</td>
                        <td className="px-3 py-2 font-mono-data text-xs text-gst-text text-right">{r.iamt.toFixed(2)}</td>
                        <td className="px-3 py-2 font-mono-data text-xs text-gst-text text-right">{r.camt.toFixed(2)}</td>
                        <td className="px-3 py-2 font-mono-data text-xs text-gst-text text-right">{r.samt.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            <div className="mt-3 flex items-center justify-between px-1 flex-wrap gap-2">
              <div className="flex items-center gap-6">
                <span className="text-xs text-gst-text-muted">
                  Total Taxable: <span className="font-mono-data text-gst-text">₹{totalTx.toFixed(2)}</span>
                </span>
                <span className="text-xs text-gst-text-muted">
                  Total Tax: <span className="font-mono-data text-gst-text">₹{totalTax.toFixed(2)}</span>
                </span>
              </div>
              {g1?.hsn?.chksum && <span className="text-[10px] font-mono-data text-gst-text-muted">chksum: {g1.hsn.chksum.slice(0, 12)}…</span>}
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          <div className="bg-gst-surface border border-gst-border-default p-5">
            <h3 className="font-display font-semibold text-sm text-gst-text mb-4">Outward Supplies (3.1)</h3>
            <table className="w-full">
              <thead>
                <tr className="border-b border-gst-border-default">
                  {["Nature", "Taxable Value", "IGST", "CGST", "SGST", "Cess"].map((h) => (
                    <th key={h} className="text-left text-[10px] uppercase tracking-wider text-gst-text-muted py-2 pr-2">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="py-2.5 pr-2 text-xs text-gst-text">Outward taxable (other than zero rated)</td>
                  <td className="py-2.5 pr-2 font-mono-data text-xs text-gst-text">{Number(g3b?.sup_details?.osup_det?.txval || 0).toFixed(2)}</td>
                  <td className="py-2.5 pr-2 font-mono-data text-xs text-gst-text">{Number(g3b?.sup_details?.osup_det?.iamt || 0).toFixed(2)}</td>
                  <td className="py-2.5 pr-2 font-mono-data text-xs text-gst-text">{Number(g3b?.sup_details?.osup_det?.camt || 0).toFixed(2)}</td>
                  <td className="py-2.5 pr-2 font-mono-data text-xs text-gst-text">{Number(g3b?.sup_details?.osup_det?.samt || 0).toFixed(2)}</td>
                  <td className="py-2.5 pr-2 font-mono-data text-xs text-gst-text">0.00</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      <div className="border border-gst-border-default">
        <button data-testid="json-preview-toggle" onClick={() => setOpen(!open)} className="w-full flex items-center justify-between px-4 py-3 bg-gst-surface hover:bg-gst-surface-el transition-colors">
          <span className="text-xs font-medium uppercase tracking-wider text-gst-text-muted">JSON Preview</span>
          <div className="flex items-center gap-2">
            {open && (
              <button onClick={(e) => { e.stopPropagation(); copy(); }} className="flex items-center gap-1 text-xs text-gst-text-secondary hover:text-gst-text">
                {copied ? <Check size={12} className="text-gst-green" /> : <Copy size={12} />} {copied ? "Copied" : "Copy"}
              </button>
            )}
            {open ? <ChevronUp size={14} className="text-gst-text-muted" /> : <ChevronDown size={14} className="text-gst-text-muted" />}
          </div>
        </button>
        {open && (
          <pre className="bg-gst-bg p-4 max-h-[400px] overflow-auto scrollbar-thin font-mono-data text-xs text-gst-text-secondary">{jsonStr}</pre>
        )}
      </div>
    </div>
  );
}
