import { useEffect, useState, useCallback } from "react";
import { toast } from "sonner";
import { Search, Filter, AlertCircle, Pencil, EyeOff, CheckCircle } from "lucide-react";
import { listExceptions, patchInvoice } from "../lib/api";

const statusConfig = {
  flagged: { dot: "bg-gst-amber", text: "text-gst-amber" },
  corrected: { dot: "bg-gst-green", text: "text-gst-green" },
  ignored: { dot: "bg-gst-text-muted", text: "text-gst-text-muted" },
};

export default function ExceptionLedger() {
  const [rows, setRows] = useState([]);
  const [selected, setSelected] = useState(null);
  const [q, setQ] = useState("");
  const [pf, setPf] = useState("All");
  const [edit, setEdit] = useState({ hsn: "", rate: "" });

  const refresh = useCallback(async () => setRows(await listExceptions()), []);
  useEffect(() => { refresh(); }, [refresh]);

  const filtered = rows.filter((r) =>
    r.invoice_no.toLowerCase().includes(q.toLowerCase()) &&
    (pf === "All" || r.platform === pf)
  );
  const sel = rows.find((r) => r.id === selected);

  useEffect(() => {
    if (sel) setEdit({ hsn: sel.hsn, rate: String(sel.rate) });
  }, [sel]);

  const apply = async (status) => {
    if (!sel) return;
    try {
      const body = { status };
      if (status === "corrected") {
        if (edit.hsn && edit.hsn !== sel.hsn) body.hsn = edit.hsn;
        if (edit.rate && parseFloat(edit.rate) !== sel.rate) body.rate = parseFloat(edit.rate);
      }
      await patchInvoice(sel.id, body);
      toast.success(`Marked ${status}`);
      setSelected(null);
      refresh();
    } catch (e) {
      toast.error(e.response?.data?.detail || e.message);
    }
  };

  return (
    <div className="flex gap-0 h-[calc(100vh-140px)]" data-testid="exception-ledger">
      <div className={`flex-1 flex flex-col min-w-0 transition-all ${selected ? "mr-[400px]" : ""}`}>
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gst-text-muted" />
            <input
              data-testid="search-input"
              type="text"
              placeholder="Search invoices..."
              value={q}
              onChange={(e) => setQ(e.target.value)}
              className="w-48 pl-8 pr-3 py-2 bg-gst-surface-el border border-gst-border-default text-sm text-gst-text placeholder:text-gst-text-muted focus:outline-none focus:border-gst-amber"
            />
          </div>
          <div className="flex items-center gap-1 px-3 py-2 bg-gst-surface-el border border-gst-border-default text-sm">
            <Filter size={14} className="text-gst-text-muted" />
            <select data-testid="platform-filter" value={pf} onChange={(e) => setPf(e.target.value)} className="bg-transparent text-sm text-gst-text focus:outline-none cursor-pointer">
              <option value="All">All Platforms</option>
              <option value="Amazon">Amazon</option>
              <option value="Flipkart">Flipkart</option>
              <option value="Meesho">Meesho</option>
              <option value="Unknown">Unknown</option>
            </select>
          </div>
          <div className="ml-auto text-xs text-gst-text-muted">{filtered.length} exceptions</div>
        </div>

        <div className="flex-1 bg-gst-surface border border-gst-border-default overflow-auto scrollbar-thin">
          <table className="w-full">
            <thead className="bg-gst-surface-el sticky top-0 z-10">
              <tr>
                {["Invoice No.", "Date", "Platform", "HSN", "Taxable", "CGST", "SGST", "IGST", "Status", "Reason"].map((h, i) => (
                  <th key={h} className={`h-10 px-3 text-[10px] font-medium uppercase tracking-wider text-gst-text-muted ${i >= 4 && i <= 7 ? "text-right" : "text-left"}`}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={10} className="p-8 text-center text-sm text-gst-text-muted">No exceptions — upload files to detect structural anomalies</td></tr>
              )}
              {filtered.map((r, i) => {
                const st = statusConfig[r.status] || statusConfig.flagged;
                return (
                  <tr
                    key={r.id}
                    data-testid={`exception-row-${i}`}
                    onClick={() => setSelected(r.id)}
                    className={`h-12 cursor-pointer transition-colors ${i % 2 === 1 ? "bg-gst-row-stripe" : "bg-gst-surface"} hover:bg-gst-surface-el ${selected === r.id ? "bg-gst-surface-el" : ""}`}
                  >
                    <td className="px-3 font-mono-data text-xs text-gst-text truncate max-w-[200px]">{r.invoice_no}</td>
                    <td className="px-3 text-xs text-gst-text-secondary">{r.invoice_date}</td>
                    <td className="px-3"><span className="px-2 py-0.5 text-[10px] uppercase tracking-wider bg-gst-surface-el border border-gst-border-default text-gst-text-muted">{r.platform}</span></td>
                    <td className="px-3 font-mono-data text-xs text-gst-text">{r.hsn}</td>
                    <td className="px-3 text-right font-mono-data text-xs text-gst-text">{Number(r.taxable_value).toFixed(2)}</td>
                    <td className="px-3 text-right font-mono-data text-xs text-gst-text">{Number(r.cgst).toFixed(2)}</td>
                    <td className="px-3 text-right font-mono-data text-xs text-gst-text">{Number(r.sgst).toFixed(2)}</td>
                    <td className="px-3 text-right font-mono-data text-xs text-gst-text">{Number(r.igst).toFixed(2)}</td>
                    <td className="px-3">
                      <span className="flex items-center gap-1.5">
                        <span className={`w-1.5 h-1.5 rounded-full ${st.dot}`} />
                        <span className={`text-xs capitalize ${st.text}`}>{r.status}</span>
                      </span>
                    </td>
                    <td className="px-3 text-xs text-gst-text-secondary truncate max-w-[240px]">{r.exception || "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {sel && (
        <div className="fixed right-0 top-14 bottom-0 w-[400px] bg-gst-surface border-l border-gst-border-default z-30 overflow-auto scrollbar-thin" data-testid="exception-detail">
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display font-semibold text-lg text-gst-text">Exception Detail</h3>
              <button onClick={() => setSelected(null)} className="text-gst-text-muted hover:text-gst-text text-xs">Close</button>
            </div>
            <div className="space-y-2 mb-4 p-4 bg-gst-row-stripe border border-gst-border-default">
              <div className="flex justify-between"><span className="text-xs text-gst-text-muted">Invoice</span><span className="font-mono-data text-xs text-gst-text">{sel.invoice_no}</span></div>
              <div className="flex justify-between"><span className="text-xs text-gst-text-muted">Date</span><span className="text-xs text-gst-text">{sel.invoice_date}</span></div>
              <div className="flex justify-between"><span className="text-xs text-gst-text-muted">Platform</span><span className="text-xs text-gst-text">{sel.platform}</span></div>
              <div className="flex justify-between"><span className="text-xs text-gst-text-muted">Buyer State</span><span className="font-mono-data text-xs text-gst-text">{sel.buyer_state_code}</span></div>
              <div className="flex justify-between"><span className="text-xs text-gst-text-muted">Taxable</span><span className="font-mono-data text-xs text-gst-text">₹{Number(sel.taxable_value).toFixed(2)}</span></div>
            </div>

            {sel.exception && (
              <div className="mb-4 p-3 bg-gst-red/10 border border-gst-red/20">
                <div className="flex items-start gap-2">
                  <AlertCircle size={14} className="text-gst-red mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="text-[10px] font-medium uppercase tracking-wider text-gst-red">Exception</span>
                    <p className="text-sm text-gst-text mt-1">{sel.exception}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="mb-6 space-y-3">
              <div>
                <label className="text-[10px] font-medium uppercase tracking-wider text-gst-text-muted">HSN Code</label>
                <input value={edit.hsn} onChange={(e) => setEdit({ ...edit, hsn: e.target.value })} data-testid="edit-hsn" className="mt-1 w-full px-3 py-2 bg-gst-surface-el border border-gst-border-default text-sm font-mono-data text-gst-text focus:outline-none focus:border-gst-amber" />
              </div>
              <div>
                <label className="text-[10px] font-medium uppercase tracking-wider text-gst-text-muted">Tax Rate (%)</label>
                <input value={edit.rate} onChange={(e) => setEdit({ ...edit, rate: e.target.value })} data-testid="edit-rate" type="number" step="0.01" className="mt-1 w-full px-3 py-2 bg-gst-surface-el border border-gst-border-default text-sm font-mono-data text-gst-text focus:outline-none focus:border-gst-amber" />
              </div>
              <div>
                <label className="text-[10px] font-medium uppercase tracking-wider text-gst-text-muted">IMS Status (buyer)</label>
                <div className="mt-1 grid grid-cols-3 gap-1">
                  {["pending", "accepted", "rejected"].map(s => (
                    <button key={s} data-testid={`ims-${s}`} onClick={async () => { await patchInvoice(sel.id, { ims_status: s }); toast.success(`IMS: ${s}`); refresh(); }} className={`py-1.5 text-[10px] uppercase tracking-wider border ${sel.ims_status === s ? "border-gst-amber bg-gst-amber-dim text-gst-amber" : "border-gst-border-default text-gst-text-muted hover:text-gst-text"}`}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <button data-testid="apply-fix-btn" onClick={() => apply("corrected")} className="w-full py-2.5 bg-gst-amber text-gst-text-light text-sm font-medium hover:brightness-110 inline-flex items-center justify-center gap-2">
                <CheckCircle size={14} /> Apply Fix
              </button>
              <button data-testid="ignore-btn" onClick={() => apply("ignored")} className="w-full py-2.5 border border-gst-border-default text-gst-text text-sm font-medium hover:border-gst-text-secondary inline-flex items-center justify-center gap-2">
                <EyeOff size={14} /> Ignore Exception
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
