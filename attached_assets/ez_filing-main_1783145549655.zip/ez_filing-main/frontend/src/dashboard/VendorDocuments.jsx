import { useEffect, useState } from "react";
import { FileText, CheckCircle, AlertCircle } from "lucide-react";
import { listVendorInvoices } from "../lib/api";

export default function VendorDocuments() {
  const [rows, setRows] = useState([]);
  useEffect(() => { listVendorInvoices().then(setRows).catch(() => {}); }, []);

  const confidenceColor = (c) => {
    if (c === "high") return "text-gst-green";
    if (c === "low") return "text-gst-red";
    return "text-gst-amber";
  };

  const totalITC = rows.reduce((s, r) => s + (r.itc_eligible ? (Number(r.cgst) + Number(r.sgst) + Number(r.igst)) : 0), 0);

  return (
    <div className="space-y-6" data-testid="vendor-documents">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-gst-surface border border-gst-border-default p-5">
          <div className="text-[10px] uppercase tracking-widest text-gst-text-muted mb-2">PDF Invoices</div>
          <div className="font-display font-semibold text-2xl text-gst-text">{rows.length}</div>
        </div>
        <div className="bg-gst-surface border border-gst-border-default p-5">
          <div className="text-[10px] uppercase tracking-widest text-gst-text-muted mb-2">ITC Eligible</div>
          <div className="font-display font-semibold text-2xl text-gst-green">{rows.filter(r => r.itc_eligible).length}</div>
        </div>
        <div className="bg-gst-surface border border-gst-border-default p-5">
          <div className="text-[10px] uppercase tracking-widest text-gst-text-muted mb-2">Total ITC (₹)</div>
          <div className="font-display font-semibold text-2xl text-gst-amber font-mono-data">{totalITC.toFixed(2)}</div>
        </div>
      </div>

      <div className="bg-gst-surface border border-gst-border-default overflow-auto scrollbar-thin">
        <table className="w-full">
          <thead className="bg-gst-surface-el">
            <tr>
              {["Vendor", "GSTIN", "Invoice No.", "Date", "HSN", "Taxable", "CGST", "SGST", "IGST", "Confidence", "ITC"].map(h => (
                <th key={h} className="h-10 px-3 text-left text-[10px] uppercase tracking-wider text-gst-text-muted">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={11} className="p-8 text-center text-sm text-gst-text-muted">No vendor PDFs uploaded yet — drop PDF invoices in File Control Center</td></tr>}
            {rows.map((r, i) => (
              <tr key={r.id} data-testid={`vendor-row-${i}`} className={i % 2 === 1 ? "bg-gst-row-stripe" : ""}>
                <td className="px-3 py-2 text-xs text-gst-text truncate max-w-[160px]"><div className="flex items-center gap-2"><FileText size={12} className="text-gst-text-muted" />{r.vendor_name || "—"}</div></td>
                <td className="px-3 py-2 font-mono-data text-xs text-gst-text">{r.vendor_gstin || "—"}</td>
                <td className="px-3 py-2 font-mono-data text-xs text-gst-text">{r.invoice_no}</td>
                <td className="px-3 py-2 text-xs text-gst-text-secondary">{r.invoice_date}</td>
                <td className="px-3 py-2 font-mono-data text-xs text-gst-text">{r.hsn || "—"}</td>
                <td className="px-3 py-2 font-mono-data text-xs text-gst-text text-right">{Number(r.taxable_value).toFixed(2)}</td>
                <td className="px-3 py-2 font-mono-data text-xs text-gst-text text-right">{Number(r.cgst).toFixed(2)}</td>
                <td className="px-3 py-2 font-mono-data text-xs text-gst-text text-right">{Number(r.sgst).toFixed(2)}</td>
                <td className="px-3 py-2 font-mono-data text-xs text-gst-text text-right">{Number(r.igst).toFixed(2)}</td>
                <td className="px-3 py-2">
                  <span className={`text-[10px] uppercase tracking-wider ${confidenceColor(r.extraction_confidence)}`}>
                    {r.extraction_confidence}
                  </span>
                </td>
                <td className="px-3 py-2">
                  {r.itc_eligible ? <span className="inline-flex items-center gap-1 text-xs text-gst-green"><CheckCircle size={12} /> Eligible</span> : <span className="inline-flex items-center gap-1 text-xs text-gst-text-muted"><AlertCircle size={12} /> Blocked</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
