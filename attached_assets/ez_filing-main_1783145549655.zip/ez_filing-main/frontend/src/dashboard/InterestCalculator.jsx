import { useState } from "react";
import { Calculator } from "lucide-react";
import { api } from "../lib/api";

export default function InterestCalculator() {
  const [liability, setLiability] = useState("50000");
  const [days, setDays] = useState("30");
  const [rate, setRate] = useState("18");
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);

  const calc = async () => {
    setBusy(true);
    try {
      const { data } = await api.post("/interest", {
        net_cash_liability: parseFloat(liability) || 0,
        days_delayed: parseInt(days, 10) || 0,
        rate_pct: parseFloat(rate) || 18,
      });
      setResult(data);
    } finally { setBusy(false); }
  };

  return (
    <div className="bg-gst-surface border border-gst-border-default p-6" data-testid="interest-calculator">
      <div className="flex items-center gap-2 mb-4">
        <Calculator size={16} className="text-gst-amber" />
        <h3 className="font-display font-semibold text-sm text-gst-text">Interest Estimator — Rule 88B</h3>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
        <div>
          <label className="text-[10px] uppercase tracking-widest text-gst-text-muted">Net Cash Liability ₹</label>
          <input data-testid="interest-liability" type="number" value={liability} onChange={e => setLiability(e.target.value)} className="mt-1 w-full px-3 py-2 bg-gst-surface-el border border-gst-border-default text-sm font-mono-data text-gst-text focus:outline-none focus:border-gst-amber" />
        </div>
        <div>
          <label className="text-[10px] uppercase tracking-widest text-gst-text-muted">Days Delayed</label>
          <input data-testid="interest-days" type="number" value={days} onChange={e => setDays(e.target.value)} className="mt-1 w-full px-3 py-2 bg-gst-surface-el border border-gst-border-default text-sm font-mono-data text-gst-text focus:outline-none focus:border-gst-amber" />
        </div>
        <div>
          <label className="text-[10px] uppercase tracking-widest text-gst-text-muted">Rate % p.a.</label>
          <input data-testid="interest-rate" type="number" value={rate} onChange={e => setRate(e.target.value)} className="mt-1 w-full px-3 py-2 bg-gst-surface-el border border-gst-border-default text-sm font-mono-data text-gst-text focus:outline-none focus:border-gst-amber" />
        </div>
      </div>
      <button data-testid="interest-calc-btn" onClick={calc} disabled={busy} className="px-4 py-2 bg-gst-amber text-gst-text-light text-xs font-medium hover:brightness-110 disabled:opacity-40">
        {busy ? "Calculating…" : "Calculate"}
      </button>
      {result && (
        <div className="mt-4 grid grid-cols-2 gap-4 p-4 bg-gst-row-stripe border border-gst-border-default" data-testid="interest-result">
          <div><div className="text-[10px] uppercase text-gst-text-muted">Interest</div><div className="font-mono-data text-lg text-gst-amber">₹ {result.interest.toFixed(2)}</div></div>
          <div><div className="text-[10px] uppercase text-gst-text-muted">Total Payable</div><div className="font-mono-data text-lg text-gst-text">₹ {result.total_payable.toFixed(2)}</div></div>
          <div className="col-span-2 text-[10px] text-gst-text-muted">{result.rule}</div>
        </div>
      )}
    </div>
  );
}
