import { useEffect, useState, useRef, useCallback } from "react";
import { toast } from "sonner";
import { Upload, FileText, File as FileIcon, TrendingUp, ShoppingCart, CheckCircle, XCircle, Loader2, Trash2 } from "lucide-react";
import { uploadFile, listUploads, fetchStats, resetAll } from "../lib/api";

export default function FileControlCenter() {
  const [files, setFiles] = useState([]);
  const [stats, setStats] = useState(null);
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef(null);

  const refresh = useCallback(async () => {
    try {
      const [u, s] = await Promise.all([listUploads(), fetchStats()]);
      setFiles(u);
      setStats(s);
    } catch (e) {
      toast.error("Failed to refresh: " + (e.response?.data?.detail || e.message));
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const doUpload = async (fileList) => {
    if (!fileList || !fileList.length) return;
    setUploading(true);
    for (const f of fileList) {
      try {
        const res = await uploadFile(f);
        toast.success(`${f.name}: ${res.rows_parsed} rows parsed (${res.exceptions} exceptions)`);
      } catch (e) {
        toast.error(`${f.name}: ${e.response?.data?.detail || e.message}`);
      }
    }
    setUploading(false);
    refresh();
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    doUpload(Array.from(e.dataTransfer.files));
  };

  const onReset = async () => {
    if (!window.confirm("Reset all data?")) return;
    await resetAll();
    toast.success("All data cleared");
    refresh();
  };

  const statCards = [
    { label: "Documents Uploaded", v: stats?.documents_uploaded ?? 0 },
    { label: "Invoices Extracted", v: stats?.invoices_extracted ?? 0 },
    { label: "Exceptions Flagged", v: stats?.exceptions_flagged ?? 0 },
    { label: "Returns Ready", v: stats?.returns_ready ?? 0 },
  ];

  return (
    <div className="space-y-6" data-testid="file-control-center">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((s) => (
          <div key={s.label} data-testid={`stat-${statCards.indexOf(s)}`} className="bg-gst-surface border border-gst-border-default p-5">
            <div className="text-[10px] font-medium uppercase tracking-widest text-gst-text-muted mb-2">{s.label}</div>
            <div className="font-display font-semibold text-2xl text-gst-text">{s.v}</div>
            <div className="mt-1 flex items-center gap-1 font-mono-data text-xs text-gst-green">
              <TrendingUp size={12} /> live
            </div>
          </div>
        ))}
      </div>

      <div
        data-testid="dropzone"
        className={`bg-gst-surface border-2 border-dashed p-12 text-center transition-colors ${dragging ? "border-gst-amber bg-gst-amber-dim" : "border-gst-border-default"}`}
        onDragEnter={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDragOver={(e) => e.preventDefault()}
        onDrop={onDrop}
      >
        <input
          ref={inputRef}
          type="file"
          multiple
          accept=".csv,.xlsx,.xls,.pdf"
          className="hidden"
          onChange={(e) => doUpload(Array.from(e.target.files))}
          data-testid="file-input"
        />
        {uploading ? (
          <Loader2 size={48} className="mx-auto text-gst-amber mb-4 animate-spin" />
        ) : (
          <Upload size={48} className="mx-auto text-gst-text-muted mb-4" />
        )}
        <p className="text-base text-gst-text-secondary mb-1">
          Drop marketplace CSV/XLSX exports OR vendor PDF invoices here
        </p>
        <p className="text-xs text-gst-text-muted mb-6">
          CSV/XLSX → sales ledger · PDF → AI-extracted vendor ITC · Max 50MB
        </p>
        <div className="flex items-center justify-center gap-3">
          <button
            data-testid="browse-btn"
            onClick={() => inputRef.current?.click()}
            className="px-5 py-2 border border-gst-border-default text-gst-text text-sm font-medium hover:border-gst-text-secondary"
          >
            Browse Files
          </button>
          <button
            data-testid="reset-btn"
            onClick={onReset}
            className="px-5 py-2 border border-gst-red/50 text-gst-red text-sm font-medium hover:bg-gst-red/10 inline-flex items-center gap-2"
          >
            <Trash2 size={14} /> Clear All
          </button>
        </div>
      </div>

      <div>
        <h3 className="text-xs font-medium uppercase tracking-widest text-gst-text-muted mb-3">
          Recent Uploads
        </h3>
        <div className="bg-gst-surface border border-gst-border-default">
          {files.length === 0 && (
            <div className="p-8 text-center text-sm text-gst-text-muted">No uploads yet — drop a file above to get started</div>
          )}
          {files.map((f, i) => (
            <div key={f.id} className={`flex items-center gap-4 px-4 py-3 ${i > 0 ? "border-t border-gst-border-default" : ""}`}>
              <div className="flex-shrink-0">
                {f.file_type === "pdf" ? <FileIcon size={16} className="text-gst-text-muted" /> : <FileText size={16} className="text-gst-text-muted" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-mono-data text-sm text-gst-text truncate">{f.filename}</span>
                  <span className="flex-shrink-0 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider bg-gst-surface-el border border-gst-border-default text-gst-text-muted">
                    {f.platform}
                  </span>
                </div>
                <span className="text-xs text-gst-text-muted">{(f.size_bytes / 1024).toFixed(1)} KB · {f.row_count} rows</span>
              </div>
              <div className="flex-shrink-0">
                {f.status === "processing" && <span className="flex items-center gap-1.5 text-xs text-gst-text-muted"><Loader2 size={12} className="animate-spin text-gst-amber" /> Processing</span>}
                {f.status === "completed" && <span className="flex items-center gap-1.5 text-xs text-gst-green"><CheckCircle size={12} /> Completed</span>}
                {f.status === "failed" && <span className="flex items-center gap-1.5 text-xs text-gst-red"><XCircle size={12} /> Failed</span>}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-xs font-medium uppercase tracking-widest text-gst-text-muted mb-3">
          Marketplace Integrations
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {["Amazon", "Flipkart", "Meesho"].map((n) => (
            <div key={n} className="bg-gst-surface border border-gst-border-default p-5 flex items-center gap-4">
              <div className="w-12 h-12 bg-gst-surface-el border border-gst-border-default flex items-center justify-center">
                <ShoppingCart size={20} className="text-gst-text-muted" />
              </div>
              <div className="flex-1">
                <h4 className="font-display font-semibold text-sm text-gst-text">{n}</h4>
                <span className="text-[10px] font-medium uppercase tracking-wider text-gst-text-muted">CSV Upload Ready</span>
              </div>
              <button className="px-3 py-1 text-xs font-medium text-gst-text-muted border border-gst-border-default hover:text-gst-text">Manage</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
