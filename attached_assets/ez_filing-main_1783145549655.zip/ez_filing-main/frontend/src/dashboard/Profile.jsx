import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Save, LogIn } from "lucide-react";
import { api } from "../lib/api";
import { useAuth, loginWithGoogle } from "../lib/auth";

const STATE_OPTIONS = [
  ["27", "Maharashtra"], ["29", "Karnataka"], ["33", "Tamil Nadu"], ["07", "Delhi"],
  ["19", "West Bengal"], ["36", "Telangana"], ["09", "Uttar Pradesh"], ["24", "Gujarat"],
  ["32", "Kerala"], ["06", "Haryana"], ["08", "Rajasthan"], ["23", "Madhya Pradesh"],
  ["21", "Odisha"], ["37", "Andhra Pradesh"], ["10", "Bihar"], ["22", "Chhattisgarh"],
];

export default function Profile() {
  const { user, loading } = useAuth();
  const [p, setP] = useState({ gstin: "", seller_state_code: "27", business_name: "", filing_period: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get("/profile", { withCredentials: true }).then(r => setP({
      gstin: r.data.gstin || "",
      seller_state_code: r.data.seller_state_code || "27",
      business_name: r.data.business_name || "",
      filing_period: r.data.filing_period || new Date().toISOString().slice(5, 7) + new Date().getFullYear(),
    }));
  }, []);

  const save = async () => {
    if (!user) return toast.error("Sign in first");
    setSaving(true);
    try {
      await api.put("/profile", p, { withCredentials: true });
      toast.success("Profile saved");
    } catch (e) {
      toast.error(e.response?.data?.detail || e.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="p-6 text-gst-text-muted">Loading…</div>;

  return (
    <div className="max-w-2xl space-y-6" data-testid="profile-page">
      {!user && (
        <div className="bg-gst-amber/10 border border-gst-amber/40 p-5 flex items-center justify-between gap-4">
          <div>
            <div className="text-sm text-gst-text font-medium">Sign in required</div>
            <div className="text-xs text-gst-text-secondary mt-1">Sign in with Google to save your GST profile.</div>
          </div>
          <button data-testid="google-login-btn" onClick={loginWithGoogle} className="inline-flex items-center gap-2 px-5 py-2.5 bg-gst-amber text-gst-text-light text-sm font-medium hover:brightness-110">
            <LogIn size={14} /> Sign in
          </button>
        </div>
      )}
      {user && (
        <div className="bg-gst-surface border border-gst-border-default p-4 flex items-center gap-3">
          {user.picture && <img src={user.picture} alt="" className="w-10 h-10" />}
          <div><div className="text-sm text-gst-text">{user.name}</div><div className="text-xs text-gst-text-muted">{user.email}</div></div>
        </div>
      )}

      <div className="bg-gst-surface border border-gst-border-default p-6 space-y-4">
        <h2 className="font-display font-semibold text-lg text-gst-text">GST Profile</h2>
        <div>
          <label className="text-[10px] uppercase tracking-widest text-gst-text-muted">Business Name</label>
          <input data-testid="input-business-name" value={p.business_name} onChange={e => setP({ ...p, business_name: e.target.value })} className="mt-1 w-full px-3 py-2 bg-gst-surface-el border border-gst-border-default text-sm text-gst-text focus:outline-none focus:border-gst-amber" />
        </div>
        <div>
          <label className="text-[10px] uppercase tracking-widest text-gst-text-muted">GSTIN (15 chars)</label>
          <input data-testid="input-gstin" value={p.gstin} onChange={e => setP({ ...p, gstin: e.target.value.toUpperCase() })} maxLength={15} placeholder="27AABCU9603R1ZX" className="mt-1 w-full px-3 py-2 bg-gst-surface-el border border-gst-border-default text-sm font-mono-data text-gst-text focus:outline-none focus:border-gst-amber" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-[10px] uppercase tracking-widest text-gst-text-muted">Seller State</label>
            <select data-testid="input-seller-state" value={p.seller_state_code} onChange={e => setP({ ...p, seller_state_code: e.target.value })} className="mt-1 w-full px-3 py-2 bg-gst-surface-el border border-gst-border-default text-sm text-gst-text focus:outline-none focus:border-gst-amber">
              {STATE_OPTIONS.map(([c, n]) => <option key={c} value={c}>{c} — {n}</option>)}
            </select>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-widest text-gst-text-muted">Filing Period (MMYYYY)</label>
            <input data-testid="input-filing-period" value={p.filing_period} onChange={e => setP({ ...p, filing_period: e.target.value })} maxLength={6} placeholder="072026" className="mt-1 w-full px-3 py-2 bg-gst-surface-el border border-gst-border-default text-sm font-mono-data text-gst-text focus:outline-none focus:border-gst-amber" />
          </div>
        </div>
        <button data-testid="save-profile-btn" onClick={save} disabled={saving || !user} className="inline-flex items-center gap-2 px-5 py-2.5 bg-gst-amber text-gst-text-light text-sm font-medium disabled:opacity-40 hover:brightness-110">
          <Save size={14} /> {saving ? "Saving…" : "Save Profile"}
        </button>
      </div>
    </div>
  );
}
