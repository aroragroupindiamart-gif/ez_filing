import { NavLink } from "react-router-dom";
import { Upload, AlertTriangle, FileCheck, FileText, BarChart3, FolderOpen, Settings, Users, CreditCard } from "lucide-react";

const sections = [
  { label: "WORKSPACE", items: [
    { to: "/dashboard/files", label: "File Control Center", icon: Upload },
    { to: "/dashboard/exceptions", label: "Exception Ledger", icon: AlertTriangle },
    { to: "/dashboard/compliance", label: "Compliance Preview", icon: FileCheck },
  ]},
  { label: "DATA", items: [
    { to: "/dashboard/invoices", label: "Invoices", icon: FileText },
    { to: "/dashboard/reports", label: "Marketplace Reports", icon: BarChart3 },
    { to: "/dashboard/documents", label: "Vendor Documents", icon: FolderOpen },
  ]},
  { label: "SETTINGS", items: [
    { to: "/dashboard/profile", label: "GST Profile", icon: Settings },
    { to: "/dashboard/team", label: "Team", icon: Users },
    { to: "/dashboard/billing", label: "Billing", icon: CreditCard },
  ]},
];

export default function DashboardSidebar() {
  return (
    <aside data-testid="dashboard-sidebar" className="w-60 h-screen bg-gst-surface border-r border-gst-border-default flex flex-col fixed left-0 top-0 z-40">
      <div className="h-14 flex items-center px-4 border-b border-gst-border-default">
        <span className="font-display font-semibold text-base text-gst-text">
          GST<span className="text-gst-amber">-</span>EZ
        </span>
      </div>
      <nav className="flex-1 overflow-y-auto py-4 scrollbar-thin">
        {sections.map((s) => (
          <div key={s.label} className="mb-6">
            <div className="px-4 mb-2">
              <span className="text-[10px] font-medium uppercase tracking-widest text-gst-text-muted">{s.label}</span>
            </div>
            <ul>
              {s.items.map((it) => {
                const Icon = it.icon;
                return (
                  <li key={it.to}>
                    <NavLink
                      to={it.to}
                      end
                      data-testid={`nav-${it.to.split("/").pop()}`}
                      className={({ isActive }) =>
                        `flex items-center gap-3 h-10 px-4 text-xs font-medium uppercase tracking-wide transition-colors ${
                          isActive
                            ? "border-l-[3px] border-l-gst-amber bg-gst-surface-el/50 text-gst-text"
                            : "text-gst-text-muted hover:bg-gst-surface-el hover:text-gst-text-secondary"
                        }`
                      }
                    >
                      <Icon size={14} />
                      {it.label}
                    </NavLink>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
}
