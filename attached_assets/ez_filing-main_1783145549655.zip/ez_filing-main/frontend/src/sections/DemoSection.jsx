import { useEffect, useState } from "react";
import { Upload, FileText, CheckCircle, Download } from "lucide-react";

const steps = [
  { icon: Upload, title: "Upload", d: "Drop marketplace CSVs and vendor PDFs. Amazon, Flipkart, and Meesho settlement reports." },
  { icon: FileText, title: "Extract", d: "Auto-detect columns from any schema — invoice#, HSN, taxable value, PoS state." },
  { icon: CheckCircle, title: "Validate", d: "Automatic GST math: PoS routing, HSN aggregation, credit note adjustments, ITC matching." },
  { icon: Download, title: "Export", d: "Download GSTN-portal-ready JSON for GSTR-1 (Tables 4, 7, 12, 14/15) and GSTR-3B." },
];

export default function DemoSection() {
  const [active, setActive] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setActive((p) => (p + 1) % steps.length), 3000);
    return () => clearInterval(id);
  }, []);
  return (
    <section id="demo" className="bg-gst-bg py-20 lg:py-28">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div>
            <h2 className="font-display font-semibold text-3xl lg:text-[40px] leading-tight text-gst-text tracking-tight mb-10">
              From Raw Data to Filing in 4 Steps
            </h2>
            <div className="relative space-y-6">
              <div className="absolute left-[23px] top-8 bottom-8 w-0.5 bg-gst-border-default" />
              {steps.map((s, i) => {
                const Icon = s.icon;
                const on = i === active;
                return (
                  <div key={i} className={`relative flex gap-5 p-6 bg-gst-surface border transition-all ${on ? "border-l-[3px] border-l-gst-amber border-t-gst-border-default border-r-gst-border-default border-b-gst-border-default" : "border-gst-border-default"}`}>
                    <span className={`inline-flex items-center justify-center w-12 h-12 flex-shrink-0 border ${on ? "bg-gst-amber/10 border-gst-amber text-gst-amber" : "bg-gst-surface-el border-gst-border-default text-gst-text-muted"}`}>
                      <Icon size={18} />
                    </span>
                    <div>
                      <h3 className="font-display font-semibold text-lg text-gst-text">{s.title}</h3>
                      <p className="mt-1 text-sm text-gst-text-secondary leading-relaxed">{s.d}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div>
            <div className="bg-gst-surface border border-gst-border-default h-[500px] flex items-center justify-center relative overflow-hidden">
              <div className="w-64 h-64 rounded-full border-2 border-gst-amber/40 animate-pulse-dot" />
              <div className="absolute w-48 h-48 rounded-full border border-gst-amber/60" />
              <div className="absolute w-32 h-32 rounded-full bg-gst-amber/10 border border-gst-amber flex items-center justify-center">
                <span className="font-display font-bold text-3xl text-gst-amber">₹</span>
              </div>
              {[0, 60, 120, 180, 240, 300].map((deg) => (
                <span key={deg} className="absolute w-2 h-2 bg-gst-amber rounded-full" style={{ transform: `rotate(${deg}deg) translateY(-140px)` }} />
              ))}
            </div>
            <div className="mt-4 flex items-center gap-2 justify-center">
              <span className="w-2 h-2 bg-gst-amber rounded-full animate-pulse-dot" />
              <span className="text-xs font-mono-data text-gst-text-muted">Processing invoices...</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
