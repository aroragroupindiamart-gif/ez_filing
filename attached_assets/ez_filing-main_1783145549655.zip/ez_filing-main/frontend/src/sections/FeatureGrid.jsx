import { Tag, Receipt, Wallet, MapPin, Code, AlertTriangle } from "lucide-react";

const features = [
  { icon: Tag, title: "Smart HSN Matching", d: "Auto-detect HSN codes from description text. Handles rate changes and composite supplies." },
  { icon: Receipt, title: "Credit Note Tracker", d: "Links credit notes to original invoices automatically. Tracks buyer accept/reject via IMS." },
  { icon: Wallet, title: "TCS Reconciliation", d: "Separates e-commerce operator TCS under Section 52 from your outward tax liability." },
  { icon: MapPin, title: "State-wise PoS", d: "Automatic CGST+SGST vs IGST routing based on Place of Supply rules for every transaction." },
  { icon: Code, title: "JSON Export", d: "GSTN-schema-compliant JSON output. Upload directly to the portal — no manual copy-paste." },
  { icon: AlertTriangle, title: "Exception Alerts", d: "Flag structural anomalies before filing. Inline editing — no re-upload needed." },
];

export default function FeatureGrid() {
  return (
    <section id="features" className="bg-gst-bg py-20 lg:py-28">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        <div className="text-center mb-12">
          <h2 className="font-display font-semibold text-3xl lg:text-[40px] leading-tight text-gst-text tracking-tight">
            Built for E-Commerce Compliance
          </h2>
          <p className="mt-4 text-base text-gst-text-secondary max-w-xl mx-auto">
            Every feature designed specifically for marketplace sellers filing GST in India.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <div key={i} data-testid={`feature-card-${i}`} className="bg-gst-surface border border-gst-border-default p-8 hover:border-[#3A4557] hover:-translate-y-0.5 transition-all duration-300">
                <div className="w-10 h-10 bg-gst-surface-el border border-gst-border-default flex items-center justify-center mb-5">
                  <Icon size={20} className="text-gst-amber" />
                </div>
                <h3 className="font-display font-semibold text-xl text-gst-text mb-3">{f.title}</h3>
                <p className="text-sm text-gst-text-secondary leading-relaxed">{f.d}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
