const stats = [
  { v: "2,400+", l: "Sellers" },
  { v: "18L+", l: "Invoices processed" },
  { v: "5", l: "Marketplaces" },
  { v: "99.4%", l: "Extraction accuracy" },
];
export default function StatsBand() {
  return (
    <section className="bg-gst-surface-light py-16 lg:py-20">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((s, i) => (
            <div key={i} className="text-center">
              <div className="font-display font-semibold text-3xl lg:text-[40px] text-gst-text-light tracking-tight">{s.v}</div>
              <div className="mt-2 mx-auto w-10 h-[3px] bg-gst-amber" />
              <div className="mt-2 text-xs font-medium uppercase tracking-wider text-gst-text-light-secondary">{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
