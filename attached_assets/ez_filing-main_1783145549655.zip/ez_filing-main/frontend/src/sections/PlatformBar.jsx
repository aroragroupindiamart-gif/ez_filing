const platforms = ["Amazon", "Flipkart", "Meesho", "Myntra", "Shopsy"];
export default function PlatformBar() {
  return (
    <section className="bg-gst-bg py-12 border-b border-gst-border-default">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        <p className="text-center text-xs text-gst-text-muted uppercase tracking-widest mb-6">
          Works with India&apos;s top marketplaces
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4">
          {platforms.map((n) => (
            <div key={n} className="px-6 py-2.5 bg-gst-surface border border-gst-border-default text-sm font-medium text-gst-text-muted opacity-60 hover:opacity-100 transition-opacity">
              {n}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
