import { FileX, FileSpreadsheet, AlertTriangle } from "lucide-react";

const pain = [
  { icon: FileX, title: "Multiple formats", d: "Settlement reports from Amazon, Flipkart, and Meesho use different schemas. Vendor invoices arrive as unstructured PDFs." },
  { icon: FileSpreadsheet, title: "Manual reconciliation", d: "You (or your CA) stitch these together by hand every month — mapping HSN codes, splitting tax rates, matching credits." },
  { icon: AlertTriangle, title: "Error-prone filings", d: "One wrong HSN rate split or missed credit note means a GST notice, penalty interest, or blocked ITC." },
];

export default function ProblemSection() {
  return (
    <section className="bg-gst-surface-light py-20 lg:py-28">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          <div className="lg:col-span-7">
            <h2 className="font-display font-semibold text-3xl lg:text-[40px] leading-tight text-gst-text-light tracking-tight">
              The GST Filing Problem for E-Commerce Sellers
            </h2>
            <div className="mt-10 space-y-8">
              {pain.map((p, i) => (
                <div key={i} className="flex gap-4">
                  <div className="flex-shrink-0 mt-1"><div className="w-3 h-3 bg-gst-red" /></div>
                  <div>
                    <h3 className="font-display font-semibold text-lg text-gst-text-light">{p.title}</h3>
                    <p className="mt-1 text-sm text-gst-text-light-secondary leading-relaxed">{p.d}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="lg:col-span-5">
            <div className="bg-gst-surface border border-gst-border-default p-8 h-full flex items-center justify-center min-h-[320px]">
              <div className="relative w-full max-w-[260px] h-52">
                <div className="absolute top-0 left-4 w-32 h-40 bg-gst-surface-el border border-gst-border-default rotate-[-8deg] flex items-center justify-center">
                  <span className="text-xs font-mono-data text-gst-text-muted">PDF</span>
                </div>
                <div className="absolute top-6 left-16 w-32 h-40 bg-gst-surface-el border border-gst-border-default rotate-[6deg] flex items-center justify-center">
                  <span className="text-xs font-mono-data text-gst-text-muted">CSV</span>
                </div>
                <div className="absolute top-12 left-8 w-32 h-40 bg-gst-surface-el border border-gst-border-default flex items-center justify-center">
                  <span className="text-xs font-mono-data text-gst-text-muted">XLSX</span>
                </div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-gst-amber/10 border-2 border-gst-amber flex items-center justify-center">
                  <span className="text-3xl font-bold text-gst-amber">!</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
