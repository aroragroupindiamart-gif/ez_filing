import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      <div className="absolute inset-0 hero-grid" aria-hidden />
      <div className="absolute inset-0 vignette-overlay" aria-hidden />
      <div className="absolute top-24 left-1/4 w-64 h-64 bg-gst-amber/10 blur-3xl rounded-full" aria-hidden />
      <div className="absolute bottom-24 right-1/4 w-64 h-64 bg-gst-blue/10 blur-3xl rounded-full" aria-hidden />

      <div className="relative z-10 max-w-[1200px] mx-auto px-6 lg:px-12 text-center py-32">
        <h1 className="font-display font-bold text-5xl sm:text-6xl lg:text-7xl text-gst-text text-shadow-hero leading-[0.9] tracking-tight">
          GST
          <span className="inline-flex items-center ml-2 align-middle">
            <span className="px-2 py-0.5 text-xs font-medium bg-gst-amber text-gst-text-light tracking-wide">BETA</span>
          </span>
          <br />
          ECOM-EZ
        </h1>
        <p className="mt-6 text-lg sm:text-xl text-gst-text-secondary font-body">
          E-Commerce GST Filing, Automated
        </p>
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link to="/dashboard" data-testid="hero-cta-primary" className="inline-flex items-center gap-2 px-6 py-3 bg-gst-amber text-gst-text-light text-sm font-medium hover:brightness-110 transition-all">
            Start Free Trial <ArrowRight size={16} />
          </Link>
          <button
            data-testid="hero-cta-secondary"
            onClick={() => document.getElementById("demo")?.scrollIntoView({ behavior: "smooth" })}
            className="inline-flex items-center gap-2 px-6 py-3 border border-gst-border-default text-gst-text text-sm font-medium hover:border-gst-text-secondary"
          >
            View Demo
          </button>
        </div>
        <div className="mt-12 flex items-center justify-center gap-3">
          <div className="flex -space-x-2">
            {[0, 1, 2].map((i) => (
              <div key={i} className="w-8 h-8 rounded-full bg-gst-surface-el border-2 border-gst-bg flex items-center justify-center text-[10px] text-gst-text-secondary font-mono-data">
                {["AS", "PK", "RM"][i]}
              </div>
            ))}
          </div>
          <span className="text-xs text-gst-text-muted tracking-wide">Trusted by 2,400+ sellers</span>
        </div>
      </div>
    </section>
  );
}
