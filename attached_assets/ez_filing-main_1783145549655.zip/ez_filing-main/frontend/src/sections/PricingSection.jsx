import { Link } from "react-router-dom";
import { Check } from "lucide-react";

const plans = [
  { name: "Starter", price: "499", period: "/month", popular: false,
    features: ["Up to 500 invoices/month", "Amazon + Flipkart", "GSTR-1 JSON export", "Email support"], cta: "Start Free Trial" },
  { name: "Growth", price: "1,499", period: "/month", popular: true,
    features: ["Up to 3,000 invoices/month", "All 5 marketplaces", "GSTR-1 + GSTR-3B export", "Priority support", "Exception ledger access"], cta: "Start Free Trial" },
  { name: "Enterprise", price: "Custom", period: "", popular: false,
    features: ["Unlimited invoices", "Custom marketplace connectors", "API access", "Dedicated account manager", "White-label option"], cta: "Contact Sales" },
];

export default function PricingSection() {
  return (
    <section id="pricing" className="bg-gst-bg py-20 lg:py-28">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        <div className="text-center mb-12">
          <h2 className="font-display font-semibold text-3xl lg:text-[40px] leading-tight text-gst-text tracking-tight">
            Simple, Transparent Pricing
          </h2>
          <p className="mt-4 text-base text-gst-text-secondary max-w-xl mx-auto">
            No hidden charges. No per-filing fees. One flat monthly rate.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((p, i) => (
            <div key={i} data-testid={`pricing-plan-${p.name.toLowerCase()}`} className={`bg-gst-surface border p-8 relative ${p.popular ? "border-t-[2px] border-t-gst-amber border-l-gst-border-default border-r-gst-border-default border-b-gst-border-default" : "border-gst-border-default"}`}>
              {p.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-gst-amber text-gst-text-light text-[10px] font-semibold uppercase tracking-wider">
                  Most Popular
                </div>
              )}
              <h3 className="font-display font-semibold text-lg text-gst-text">{p.name}</h3>
              <div className="mt-4 flex items-baseline gap-1">
                {p.price !== "Custom" && <span className="text-sm text-gst-text-muted">₹</span>}
                <span className="font-display font-bold text-4xl text-gst-text">{p.price}</span>
                {p.period && <span className="text-sm text-gst-text-muted">{p.period}</span>}
              </div>
              <ul className="mt-6 space-y-3">
                {p.features.map((f, fi) => (
                  <li key={fi} className="flex items-start gap-2.5">
                    <Check size={14} className="text-gst-teal mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-gst-text-secondary">{f}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-8">
                <Link to="/dashboard" className={`block w-full text-center py-3 text-sm font-medium transition-all ${p.popular ? "bg-gst-amber text-gst-text-light hover:brightness-110" : "border border-gst-border-default text-gst-text hover:border-gst-text-secondary"}`}>
                  {p.cta}
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
