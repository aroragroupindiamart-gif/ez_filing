export default function Footer() {
  const cols = [
    { h: "Product", items: ["Features", "Pricing", "API Docs", "Changelog"] },
    { h: "Compliance", items: ["GSTR-1 Guide", "GSTR-3B Guide", "HSN Lookup", "Rate Finder"] },
    { h: "Company", items: ["About", "Blog", "Careers", "Contact"] },
    { h: "Legal", items: ["Privacy Policy", "Terms of Service", "GST Disclaimer"] },
  ];
  return (
    <footer className="bg-gst-bg border-t border-gst-border-default" data-testid="site-footer">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {cols.map((c) => (
            <div key={c.h}>
              <h4 className="text-xs font-medium uppercase tracking-wider text-gst-text-muted mb-4">{c.h}</h4>
              <ul className="space-y-3">
                {c.items.map((i) => (
                  <li key={i}><button className="text-sm text-gst-text-secondary hover:text-gst-text">{i}</button></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 pt-8 border-t border-gst-border-default flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-gst-text-muted">&copy; 2026 GST-ECOM-EZ. Built for Indian e-commerce sellers.</p>
          <p className="text-xs text-gst-text-muted">Made in India</p>
        </div>
      </div>
    </footer>
  );
}
