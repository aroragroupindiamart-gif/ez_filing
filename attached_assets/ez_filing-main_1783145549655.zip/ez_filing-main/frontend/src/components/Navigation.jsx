import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setMobileOpen(false), [location]);

  const isHome = location.pathname === "/";
  const scrollTo = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
    setMobileOpen(false);
  };

  return (
    <nav
      data-testid="site-nav"
      className={`fixed top-0 left-0 right-0 z-50 h-16 transition-all duration-200 ${
        scrolled ? "bg-gst-bg/95 backdrop-blur-sm" : "bg-gst-bg"
      }`}
      style={{ borderBottom: "1px solid #2A3547" }}
    >
      <div className="max-w-[1200px] mx-auto h-full flex items-center justify-between px-6 lg:px-12">
        <Link to="/" data-testid="nav-brand" className="flex items-center gap-1 font-display font-semibold text-lg text-gst-text">
          <span>GST</span>
          <span className="w-1.5 h-1.5 bg-gst-amber inline-block" />
          <span>ECOM-EZ</span>
        </Link>
        <div className="hidden md:flex items-center gap-8">
          {isHome && (
            <>
              <button data-testid="nav-features" onClick={() => scrollTo("features")} className="text-sm font-medium text-gst-text-secondary hover:text-gst-text">Features</button>
              <button data-testid="nav-pricing" onClick={() => scrollTo("pricing")} className="text-sm font-medium text-gst-text-secondary hover:text-gst-text">Pricing</button>
            </>
          )}
          <Link to="/dashboard" data-testid="nav-dashboard" className="text-sm font-medium text-gst-text-secondary hover:text-gst-text">Dashboard</Link>
          <Link to="/dashboard" data-testid="nav-cta" className="text-sm font-medium bg-gst-amber text-gst-text-light px-5 py-2 hover:brightness-110 transition-all">Start Free Trial</Link>
        </div>
        <button className="md:hidden text-gst-text-secondary" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      {mobileOpen && (
        <div className="md:hidden bg-gst-bg border-t border-gst-border-default">
          <div className="flex flex-col p-4 gap-4">
            {isHome && (
              <>
                <button onClick={() => scrollTo("features")} className="text-sm text-left text-gst-text-secondary">Features</button>
                <button onClick={() => scrollTo("pricing")} className="text-sm text-left text-gst-text-secondary">Pricing</button>
              </>
            )}
            <Link to="/dashboard" className="text-sm text-gst-text-secondary">Dashboard</Link>
            <Link to="/dashboard" className="text-sm bg-gst-amber text-gst-text-light px-5 py-2 text-center">Start Free Trial</Link>
          </div>
        </div>
      )}
    </nav>
  );
}
