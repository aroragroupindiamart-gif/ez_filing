# GST-ECOM-EZ — PRD & Progress

## Original Problem Statement
Build a working GST auto-filing tool from the attached PRD + design zip. E-commerce GST filing SaaS (India) for Amazon/Flipkart/Meesho sellers.
- Unified drop-zone for marketplace CSV/XLSX (vendor PDFs deferred)
- Auto-parse, normalize into internal ledger
- Automatic GST math: PoS routing (CGST+SGST vs IGST), HSN-wise aggregation
- Output GSTN-portal-ready JSON for GSTR-1 (Tables 4/7/12/14/15) and GSTR-3B (3.1, 4)
- Surface exceptions for manual correction

## Architecture
- **Frontend**: React CRA + Tailwind + shadcn/ui (dark GST-EZ theme, amber accent, Space Grotesk / Inter / JetBrains Mono)
- **Backend**: FastAPI + Motor (MongoDB) + pandas / openpyxl
- **Storage**: MongoDB collections `uploads`, `invoices`

## Personas
- E-commerce seller (Amazon/Flipkart/Meesho) — uploads settlement CSVs
- CA / accountant — reviews exceptions, applies fixes, exports JSON
- (Future) Multi-user teams

## Core Requirements — Implemented (2026-02)
- [x] Landing page (Hero, Platform bar, Problem, Demo, Feature grid, Stats, Pricing, Footer)
- [x] Dashboard shell (sidebar Workspace/Data/Settings + topbar)
- [x] File Control Center: drag-drop + browse upload for CSV/XLSX, live stats, recent uploads list, marketplace connectors card, Clear All
- [x] Backend `/api/uploads` — pandas parser with fuzzy column detection (Invoice #, HSN, Taxable Value, Rate, Ship State, Buyer GSTIN)
- [x] Backend platform auto-detect (Amazon/Flipkart/Meesho from filename & columns)
- [x] GST tax engine: intra-state → CGST+SGST split; inter-state → IGST; rate*txval/100 rounded 2dp; fills tax if only rate/value given
- [x] Exception detection: missing/invalid HSN, non-standard rate, unrecognized state, PoS/tax mismatch
- [x] Exception Ledger: table + side-panel edit (HSN, rate) + Apply Fix / Ignore
- [x] Compliance Preview: GSTR-1 sub-tables (B2B / B2C-small / HSN / E-comm supeco) with correct schema + chksum, GSTR-3B osup_det, Download JSON, JSON preview
- [x] `/api/stats`, `/api/exceptions`, `/api/invoices`, `/api/compliance/gstr1|gstr3b`, `/api/reset`

## P0 — Vendor PDF ITC (Added 2026-02, iteration 2)
- [x] `POST /api/vendor-invoices` — PDF upload → pypdf text extract → Claude Sonnet 4.5 structured JSON → vendor_invoices collection
- [x] `GET /api/vendor-invoices` list endpoint
- [x] GSTR-3B `itc_elg.itc_avl` + `itc_net` now aggregate CGST/SGST/IGST from ITC-eligible vendor invoices
- [x] Frontend: PDF accepted in main dropzone (routes to vendor endpoint); new **Vendor Documents** page with ITC stats + extraction-confidence badges + ITC-eligible flag (auto-blocked if GSTIN invalid)
- ⚠️ Requires funded EMERGENT_LLM_KEY — current key balance = 0. Add balance at Profile → Universal Key → Add Balance.

## Backlog — Deferred
- **P0**: Vendor PDF OCR (LLM Structured Outputs) → ITC feed into GSTR-3B Table 4
- **P1**: Multi-user auth (Emergent Google OAuth) + team roles
- **P1**: GSTIN profile settings (seller state, GSTIN, filing period picker)
- **P2**: IMS accept/reject tracking, interest estimator (Rule 88B), credit-note auto-adjust
- **P2**: Direct GSP filing integration
- **P2**: Marketplace API connectors (auto-pull instead of upload)

## Files
- Backend: `/app/backend/server.py`
- Frontend routes: `/app/frontend/src/App.js`
- Landing: `/app/frontend/src/pages/Home.jsx` + `src/sections/*`
- Dashboard: `/app/frontend/src/pages/Dashboard.jsx` + `src/dashboard/*`
- API client: `/app/frontend/src/lib/api.js`
- Theme: `/app/frontend/tailwind.config.js`, `/app/frontend/src/index.css`
